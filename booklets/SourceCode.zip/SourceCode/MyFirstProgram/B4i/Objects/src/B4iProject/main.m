//
//  main.m
//  Test5
//
//  Created by b4j on 7/17/14.
//  Copyright (c) 2014 Anywhere Software. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "iDesigner.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([b4iDesignerAppDelegate class]));
    }

}