#include "B4RDefines.h"

B4R::Serial* b4r_main::_serial1;
B4R::Pin* b4r_main::_pinbutton;
B4R::Pin* b4r_main::_pinledgreen;
B4R::Pin* b4r_main::_pinledyellow;
B4R::Pin* b4r_main::_pinledred;
B4R::Timer* b4r_main::_timergreenred;
bool b4r_main::_lighton;
bool b4r_main::_lightgreen;
ULong b4r_main::_bouncetime;
ULong b4r_main::_bouncedelay;
static B4R::Serial be_gann1_3;
static B4R::Pin be_gann2_3;
static B4R::Pin be_gann3_3;
static B4R::Pin be_gann3_7;
static B4R::Pin be_gann3_11;
static B4R::Timer be_gann4_3;


 void b4r_main::_appstart(){
const UInt cp = B4R::StackMemory::cp;
 //BA.debugLineNum = 20;BA.debugLine="Private Sub AppStart";
 //BA.debugLineNum = 21;BA.debugLine="Serial1.Initialize(115200)";
b4r_main::_serial1->Initialize((ULong) (115200));
 //BA.debugLineNum = 23;BA.debugLine="TimerGreenRed.Initialize(\"TimerGreenRed_Tick\", 20";
b4r_main::_timergreenred->Initialize(_timergreenred_tick,(ULong) (2000));
 //BA.debugLineNum = 27;BA.debugLine="pinButton.Initialize(pinButton.A5, pinButton.MODE";
b4r_main::_pinbutton->Initialize(Pin_A5,Pin_MODE_INPUT_PULLUP);
 //BA.debugLineNum = 28;BA.debugLine="pinButton.AddListener(\"pinButton_StateChanged\")";
b4r_main::_pinbutton->AddListener(_pinbutton_statechanged);
 //BA.debugLineNum = 30;BA.debugLine="pinLEDGreen.Initialize(7, pinLEDGreen.MODE_OUTPUT";
b4r_main::_pinledgreen->Initialize((Byte) (7),Pin_MODE_OUTPUT);
 //BA.debugLineNum = 31;BA.debugLine="pinLEDYellow.Initialize(8, pinLEDYellow.MODE_OUTP";
b4r_main::_pinledyellow->Initialize((Byte) (8),Pin_MODE_OUTPUT);
 //BA.debugLineNum = 32;BA.debugLine="pinLEDRed.Initialize(9, pinLEDRed.MODE_OUTPUT)";
b4r_main::_pinledred->Initialize((Byte) (9),Pin_MODE_OUTPUT);
 //BA.debugLineNum = 33;BA.debugLine="End Sub";
B4R::StackMemory::cp = cp;
}
void b4r_main::_endyellow(Byte _tag){
const UInt cp = B4R::StackMemory::cp;
 //BA.debugLineNum = 73;BA.debugLine="Private Sub EndYellow(Tag As Byte)";
 //BA.debugLineNum = 76;BA.debugLine="pinLEDYellow.DigitalWrite(False)	'switch OFF LED";
b4r_main::_pinledyellow->DigitalWrite(Common_False);
 //BA.debugLineNum = 77;BA.debugLine="pinLEDRed.DigitalWrite(True)			'switch ON LED Red";
b4r_main::_pinledred->DigitalWrite(Common_True);
 //BA.debugLineNum = 78;BA.debugLine="End Sub";
B4R::StackMemory::cp = cp;
}
void b4r_main::_pinbutton_statechanged(bool _state){
const UInt cp = B4R::StackMemory::cp;
 //BA.debugLineNum = 35;BA.debugLine="Private Sub pinButton_StateChanged (State As Boole";
 //BA.debugLineNum = 38;BA.debugLine="If State = False Then							'if State = False";
if (_state==Common_False) { 
 //BA.debugLineNum = 39;BA.debugLine="If Millis - BounceTime < BounceDelay Then";
if (Common_Millis()-b4r_main::_bouncetime<b4r_main::_bouncedelay) { 
 //BA.debugLineNum = 40;BA.debugLine="Return";
B4R::StackMemory::cp = cp;
if (true) return ;
 }else {
 //BA.debugLineNum = 42;BA.debugLine="pinLEDRed.DigitalWrite(True)		'switch ON the re";
b4r_main::_pinledred->DigitalWrite(Common_True);
 //BA.debugLineNum = 43;BA.debugLine="LightOn = Not(LightOn)					'change the value of";
b4r_main::_lighton = Common_Not(b4r_main::_lighton);
 //BA.debugLineNum = 44;BA.debugLine="BounceTime = Millis";
b4r_main::_bouncetime = Common_Millis();
 //BA.debugLineNum = 47;BA.debugLine="TimerGreenRed.Enabled = LightOn		'enable TimerG";
b4r_main::_timergreenred->setEnabled(b4r_main::_lighton);
 //BA.debugLineNum = 49;BA.debugLine="If LightOn = False Then						'if LightOn = Fals";
if (b4r_main::_lighton==Common_False) { 
 //BA.debugLineNum = 50;BA.debugLine="pinLEDGreen.DigitalWrite(False)	'switch OFF LE";
b4r_main::_pinledgreen->DigitalWrite(Common_False);
 //BA.debugLineNum = 51;BA.debugLine="pinLEDYellow.DigitalWrite(False)	'switch OFF L";
b4r_main::_pinledyellow->DigitalWrite(Common_False);
 //BA.debugLineNum = 52;BA.debugLine="pinLEDRed.DigitalWrite(False)		'switch OFF LED";
b4r_main::_pinledred->DigitalWrite(Common_False);
 };
 };
 };
 //BA.debugLineNum = 56;BA.debugLine="End Sub";
B4R::StackMemory::cp = cp;
}

void b4r_main::initializeProcessGlobals() {
     B4R::StackMemory::buffer = (byte*)malloc(STACK_BUFFER_SIZE);
     b4r_main::_process_globals();

   
}
void b4r_main::_process_globals(){
const UInt cp = B4R::StackMemory::cp;
 //BA.debugLineNum = 8;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 9;BA.debugLine="Public Serial1 As Serial";
b4r_main::_serial1 = &be_gann1_3;
 //BA.debugLineNum = 11;BA.debugLine="Public pinButton As Pin			'pin for the button";
b4r_main::_pinbutton = &be_gann2_3;
 //BA.debugLineNum = 12;BA.debugLine="Public pinLEDGreen, pinLEDYellow, pinLEDRed As Pi";
b4r_main::_pinledgreen = &be_gann3_3;
b4r_main::_pinledyellow = &be_gann3_7;
b4r_main::_pinledred = &be_gann3_11;
 //BA.debugLineNum = 13;BA.debugLine="Public TimerGreenRed As Timer";
b4r_main::_timergreenred = &be_gann4_3;
 //BA.debugLineNum = 14;BA.debugLine="Public LightOn = False As Boolean";
b4r_main::_lighton = Common_False;
 //BA.debugLineNum = 15;BA.debugLine="Public LightGreen = False As Boolean";
b4r_main::_lightgreen = Common_False;
 //BA.debugLineNum = 16;BA.debugLine="Private BounceTime As ULong";
b4r_main::_bouncetime = 0L;
 //BA.debugLineNum = 17;BA.debugLine="Private BounceDelay = 10 As ULong";
b4r_main::_bouncedelay = (ULong) (10);
 //BA.debugLineNum = 18;BA.debugLine="End Sub";
}
void b4r_main::_timergreenred_tick(){
const UInt cp = B4R::StackMemory::cp;
 //BA.debugLineNum = 58;BA.debugLine="Private Sub TimerGreenRed_Tick";
 //BA.debugLineNum = 59;BA.debugLine="If LightGreen = True Then					'if LightGreen = Tr";
if (b4r_main::_lightgreen==Common_True) { 
 //BA.debugLineNum = 61;BA.debugLine="CallSubPlus(\"EndYellow\", 500, 0)";
B4R::__c->CallSubPlus(_endyellow,(ULong) (500),(Byte) (0));
 //BA.debugLineNum = 62;BA.debugLine="pinLEDGreen.DigitalWrite(False)	'switch OFF LED";
b4r_main::_pinledgreen->DigitalWrite(Common_False);
 //BA.debugLineNum = 63;BA.debugLine="pinLEDYellow.DigitalWrite(True)	'switch ON LED Y";
b4r_main::_pinledyellow->DigitalWrite(Common_True);
 //BA.debugLineNum = 64;BA.debugLine="LightGreen = False							'set LightGreen to Fals";
b4r_main::_lightgreen = Common_False;
 }else {
 //BA.debugLineNum = 67;BA.debugLine="pinLEDRed.DigitalWrite(False)		'switch OFF LED R";
b4r_main::_pinledred->DigitalWrite(Common_False);
 //BA.debugLineNum = 68;BA.debugLine="pinLEDGreen.DigitalWrite(True)	'switch ON LED Gr";
b4r_main::_pinledgreen->DigitalWrite(Common_True);
 //BA.debugLineNum = 69;BA.debugLine="LightGreen = True								'set LightGreen to True";
b4r_main::_lightgreen = Common_True;
 };
 //BA.debugLineNum = 71;BA.debugLine="End Sub";
B4R::StackMemory::cp = cp;
}
