#include "B4RDefines.h"

B4R::Serial* b4r_main::_serial1;
B4R::Pin* b4r_main::_pinbutton;
B4R::Pin* b4r_main::_pinled13;
static B4R::Serial be_gann1_3;
static B4R::Pin be_gann2_3;
static B4R::Pin be_gann3_3;


 void b4r_main::_appstart(){
const UInt cp = B4R::StackMemory::cp;
 //BA.debugLineNum = 14;BA.debugLine="Private Sub AppStart";
 //BA.debugLineNum = 15;BA.debugLine="Serial1.Initialize(115200)";
b4r_main::_serial1->Initialize((ULong) (115200));
 //BA.debugLineNum = 16;BA.debugLine="Log(\"AppStart\")";
B4R::Common::LogHelper(1,102,F("AppStart"));
 //BA.debugLineNum = 18;BA.debugLine="pinLED13.Initialize(13, pinLED13.MODE_OUTPUT)";
b4r_main::_pinled13->Initialize((Byte) (13),Pin_MODE_OUTPUT);
 //BA.debugLineNum = 19;BA.debugLine="pinButton.Initialize(pinButton.A5, pinButton.MODE";
b4r_main::_pinbutton->Initialize(Pin_A5,Pin_MODE_INPUT_PULLUP);
 //BA.debugLineNum = 20;BA.debugLine="pinButton.AddListener(\"pinButton_StateChanged\")";
b4r_main::_pinbutton->AddListener(_pinbutton_statechanged);
 //BA.debugLineNum = 21;BA.debugLine="End Sub";
B4R::StackMemory::cp = cp;
}
void b4r_main::_pinbutton_statechanged(bool _state){
const UInt cp = B4R::StackMemory::cp;
 //BA.debugLineNum = 23;BA.debugLine="Sub pinButton_StateChanged (State As Boolean)";
 //BA.debugLineNum = 24;BA.debugLine="Log(\"State: \", State)";
B4R::Common::LogHelper(2,102,F("State: "),8,_state);
 //BA.debugLineNum = 26;BA.debugLine="pinLED13.DigitalWrite(Not(State))";
b4r_main::_pinled13->DigitalWrite(Common_Not(_state));
 //BA.debugLineNum = 27;BA.debugLine="End Sub";
B4R::StackMemory::cp = cp;
}

void b4r_main::initializeProcessGlobals() {
     B4R::StackMemory::buffer = (byte*)malloc(STACK_BUFFER_SIZE);
     b4r_main::_process_globals();

   
}
void b4r_main::_process_globals(){
const UInt cp = B4R::StackMemory::cp;
 //BA.debugLineNum = 8;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 9;BA.debugLine="Public Serial1 As Serial";
b4r_main::_serial1 = &be_gann1_3;
 //BA.debugLineNum = 10;BA.debugLine="Private pinButton As Pin	'pin for the button";
b4r_main::_pinbutton = &be_gann2_3;
 //BA.debugLineNum = 11;BA.debugLine="Private pinLED13 As Pin	'pin for LED 13 on the";
b4r_main::_pinled13 = &be_gann3_3;
 //BA.debugLineNum = 12;BA.debugLine="End Sub";
}
