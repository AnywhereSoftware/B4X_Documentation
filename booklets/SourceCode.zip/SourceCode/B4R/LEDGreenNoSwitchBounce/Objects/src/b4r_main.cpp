#include "B4RDefines.h"

B4R::Serial* b4r_main::_serial1;
B4R::Pin* b4r_main::_pinbutton;
B4R::Pin* b4r_main::_pinledgreen;
bool b4r_main::_lighton;
ULong b4r_main::_bouncetime;
ULong b4r_main::_bouncedelay;
static B4R::Serial be_gann1_3;
static B4R::Pin be_gann2_3;
static B4R::Pin be_gann3_3;


 void b4r_main::_appstart(){
const UInt cp = B4R::StackMemory::cp;
 //BA.debugLineNum = 17;BA.debugLine="Private Sub AppStart";
 //BA.debugLineNum = 18;BA.debugLine="Serial1.Initialize(115200)";
b4r_main::_serial1->Initialize((ULong) (115200));
 //BA.debugLineNum = 20;BA.debugLine="pinButton.Initialize(pinButton.A5, pinButton.MODE";
b4r_main::_pinbutton->Initialize(Pin_A5,Pin_MODE_INPUT_PULLUP);
 //BA.debugLineNum = 21;BA.debugLine="pinButton.AddListener(\"pinButton_StateChanged\")";
b4r_main::_pinbutton->AddListener(_pinbutton_statechanged);
 //BA.debugLineNum = 23;BA.debugLine="pinLEDGreen.Initialize(7, pinLEDGreen.MODE_OUTPUT";
b4r_main::_pinledgreen->Initialize((Byte) (7),Pin_MODE_OUTPUT);
 //BA.debugLineNum = 24;BA.debugLine="End Sub";
B4R::StackMemory::cp = cp;
}
void b4r_main::_pinbutton_statechanged(bool _state){
const UInt cp = B4R::StackMemory::cp;
 //BA.debugLineNum = 26;BA.debugLine="Private Sub pinButton_StateChanged (State As Boole";
 //BA.debugLineNum = 27;BA.debugLine="Log(\"State: \", State)							'Log the State value";
B4R::Common::LogHelper(2,102,F("State: "),8,_state);
 //BA.debugLineNum = 28;BA.debugLine="If State = False Then	'remember, False means butt";
if (_state==Common_False) { 
 //BA.debugLineNum = 29;BA.debugLine="If Millis - BounceTime < BounceDelay Then";
if (Common_Millis()-b4r_main::_bouncetime<b4r_main::_bouncedelay) { 
 //BA.debugLineNum = 30;BA.debugLine="Return";
B4R::StackMemory::cp = cp;
if (true) return ;
 }else {
 //BA.debugLineNum = 32;BA.debugLine="LightOn = Not(LightOn)";
b4r_main::_lighton = Common_Not(b4r_main::_lighton);
 //BA.debugLineNum = 33;BA.debugLine="BounceTime = Millis";
b4r_main::_bouncetime = Common_Millis();
 //BA.debugLineNum = 34;BA.debugLine="pinLEDGreen.DigitalWrite(LightOn)";
b4r_main::_pinledgreen->DigitalWrite(b4r_main::_lighton);
 };
 };
 //BA.debugLineNum = 37;BA.debugLine="End Sub";
B4R::StackMemory::cp = cp;
}

void b4r_main::initializeProcessGlobals() {
     B4R::StackMemory::buffer = (byte*)malloc(STACK_BUFFER_SIZE);
     b4r_main::_process_globals();

   
}
void b4r_main::_process_globals(){
const UInt cp = B4R::StackMemory::cp;
 //BA.debugLineNum = 8;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 9;BA.debugLine="Public Serial1 As Serial";
b4r_main::_serial1 = &be_gann1_3;
 //BA.debugLineNum = 10;BA.debugLine="Private pinButton As Pin			'pin for the button";
b4r_main::_pinbutton = &be_gann2_3;
 //BA.debugLineNum = 11;BA.debugLine="Private pinLEDGreen As Pin		'pin for the green Le";
b4r_main::_pinledgreen = &be_gann3_3;
 //BA.debugLineNum = 12;BA.debugLine="Private LightOn = False As Boolean";
b4r_main::_lighton = Common_False;
 //BA.debugLineNum = 13;BA.debugLine="Private BounceTime As ULong";
b4r_main::_bouncetime = 0L;
 //BA.debugLineNum = 14;BA.debugLine="Private BounceDelay = 20 As ULong";
b4r_main::_bouncedelay = (ULong) (20);
 //BA.debugLineNum = 15;BA.debugLine="End Sub";
}
