package B4A.AddViewsByCode;

import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.pc.*;

public class main_subs_0 {


public static RemoteObject  _activity_create(RemoteObject _firsttime) throws Exception{
try {
		Debug.PushSubsStack("Activity_Create (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,26);
if (RapidSub.canDelegate("activity_create")) return main.remoteMe.runUserSub(false, "main","activity_create", _firsttime);
Debug.locals.put("FirstTime", _firsttime);
 BA.debugLineNum = 26;BA.debugLine="Sub Activity_Create(FirstTime As Boolean)";
Debug.ShouldStop(33554432);
 BA.debugLineNum = 27;BA.debugLine="lblTitle.Initialize(\"\")";
Debug.ShouldStop(67108864);
main.mostCurrent._lbltitle.runVoidMethod ("Initialize",main.mostCurrent.activityBA,(Object)(RemoteObject.createImmutable("")));
 BA.debugLineNum = 28;BA.debugLine="lblTitle.Color = Colors.Red";
Debug.ShouldStop(134217728);
main.mostCurrent._lbltitle.runVoidMethod ("setColor",main.mostCurrent.__c.getField(false,"Colors").getField(true,"Red"));
 BA.debugLineNum = 29;BA.debugLine="lblTitle.TextSize = 20";
Debug.ShouldStop(268435456);
main.mostCurrent._lbltitle.runMethod(true,"setTextSize",BA.numberCast(float.class, 20));
 BA.debugLineNum = 30;BA.debugLine="lblTitle.TextColor = Colors.Blue";
Debug.ShouldStop(536870912);
main.mostCurrent._lbltitle.runMethod(true,"setTextColor",main.mostCurrent.__c.getField(false,"Colors").getField(true,"Blue"));
 BA.debugLineNum = 31;BA.debugLine="lblTitle.Gravity = Gravity.CENTER_HORIZONTAL + Gr";
Debug.ShouldStop(1073741824);
main.mostCurrent._lbltitle.runMethod(true,"setGravity",RemoteObject.solve(new RemoteObject[] {main.mostCurrent.__c.getField(false,"Gravity").getField(true,"CENTER_HORIZONTAL"),main.mostCurrent.__c.getField(false,"Gravity").getField(true,"CENTER_VERTICAL")}, "+",1, 1));
 BA.debugLineNum = 32;BA.debugLine="lblTitle.Text = \"Title\"";
Debug.ShouldStop(-2147483648);
main.mostCurrent._lbltitle.runMethod(true,"setText",RemoteObject.createImmutable(("Title")));
 BA.debugLineNum = 33;BA.debugLine="Activity.AddView(lblTitle, 20%x, 10dip, 60%x, 30d";
Debug.ShouldStop(1);
main.mostCurrent._activity.runVoidMethod ("AddView",(Object)((main.mostCurrent._lbltitle.getObject())),(Object)(main.mostCurrent.__c.runMethod(true,"PerXToCurrent",(Object)(BA.numberCast(float.class, 20)),main.mostCurrent.activityBA)),(Object)(main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 10)))),(Object)(main.mostCurrent.__c.runMethod(true,"PerXToCurrent",(Object)(BA.numberCast(float.class, 60)),main.mostCurrent.activityBA)),(Object)(main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 30)))));
 BA.debugLineNum = 35;BA.debugLine="pnlTest.Initialize(\"\")";
Debug.ShouldStop(4);
main.mostCurrent._pnltest.runVoidMethod ("Initialize",main.mostCurrent.activityBA,(Object)(RemoteObject.createImmutable("")));
 BA.debugLineNum = 36;BA.debugLine="pnlTest.Color = Colors.Blue";
Debug.ShouldStop(8);
main.mostCurrent._pnltest.runVoidMethod ("setColor",main.mostCurrent.__c.getField(false,"Colors").getField(true,"Blue"));
 BA.debugLineNum = 38;BA.debugLine="btnTest.Initialize(\"btnTest\")";
Debug.ShouldStop(32);
main.mostCurrent._btntest.runVoidMethod ("Initialize",main.mostCurrent.activityBA,(Object)(RemoteObject.createImmutable("btnTest")));
 BA.debugLineNum = 39;BA.debugLine="btnTest.Text = \"Test\"";
Debug.ShouldStop(64);
main.mostCurrent._btntest.runMethod(true,"setText",RemoteObject.createImmutable(("Test")));
 BA.debugLineNum = 41;BA.debugLine="lblPanelTitle.Initialize(\"\")";
Debug.ShouldStop(256);
main.mostCurrent._lblpaneltitle.runVoidMethod ("Initialize",main.mostCurrent.activityBA,(Object)(RemoteObject.createImmutable("")));
 BA.debugLineNum = 42;BA.debugLine="lblPanelTitle.Color = Colors.Red";
Debug.ShouldStop(512);
main.mostCurrent._lblpaneltitle.runVoidMethod ("setColor",main.mostCurrent.__c.getField(false,"Colors").getField(true,"Red"));
 BA.debugLineNum = 43;BA.debugLine="lblPanelTitle.TextSize = 16";
Debug.ShouldStop(1024);
main.mostCurrent._lblpaneltitle.runMethod(true,"setTextSize",BA.numberCast(float.class, 16));
 BA.debugLineNum = 44;BA.debugLine="lblPanelTitle.TextColor = Colors.Blue";
Debug.ShouldStop(2048);
main.mostCurrent._lblpaneltitle.runMethod(true,"setTextColor",main.mostCurrent.__c.getField(false,"Colors").getField(true,"Blue"));
 BA.debugLineNum = 45;BA.debugLine="lblPanelTitle.Gravity = Gravity.CENTER_HORIZONTAL";
Debug.ShouldStop(4096);
main.mostCurrent._lblpaneltitle.runMethod(true,"setGravity",RemoteObject.solve(new RemoteObject[] {main.mostCurrent.__c.getField(false,"Gravity").getField(true,"CENTER_HORIZONTAL"),main.mostCurrent.__c.getField(false,"Gravity").getField(true,"CENTER_VERTICAL")}, "+",1, 1));
 BA.debugLineNum = 46;BA.debugLine="lblPanelTitle.Text = \"Panel test\"";
Debug.ShouldStop(8192);
main.mostCurrent._lblpaneltitle.runMethod(true,"setText",RemoteObject.createImmutable(("Panel test")));
 BA.debugLineNum = 48;BA.debugLine="Activity.AddView(pnlTest, 0, lblTitle.Top + lblTi";
Debug.ShouldStop(32768);
main.mostCurrent._activity.runVoidMethod ("AddView",(Object)((main.mostCurrent._pnltest.getObject())),(Object)(BA.numberCast(int.class, 0)),(Object)(RemoteObject.solve(new RemoteObject[] {main.mostCurrent._lbltitle.runMethod(true,"getTop"),main.mostCurrent._lbltitle.runMethod(true,"getHeight"),main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 10)))}, "++",2, 1)),(Object)(main.mostCurrent.__c.runMethod(true,"PerXToCurrent",(Object)(BA.numberCast(float.class, 100)),main.mostCurrent.activityBA)),(Object)(main.mostCurrent.__c.runMethod(true,"PerYToCurrent",(Object)(BA.numberCast(float.class, 50)),main.mostCurrent.activityBA)));
 BA.debugLineNum = 49;BA.debugLine="pnlTest.AddView(lblPanelTitle, 20dip, 10dip, 100d";
Debug.ShouldStop(65536);
main.mostCurrent._pnltest.runVoidMethod ("AddView",(Object)((main.mostCurrent._lblpaneltitle.getObject())),(Object)(main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 20)))),(Object)(main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 10)))),(Object)(main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 100)))),(Object)(main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 30)))));
 BA.debugLineNum = 50;BA.debugLine="pnlTest.AddView(btnTest, 50dip, 50dip, 100dip, 60";
Debug.ShouldStop(131072);
main.mostCurrent._pnltest.runVoidMethod ("AddView",(Object)((main.mostCurrent._btntest.getObject())),(Object)(main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 50)))),(Object)(main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 50)))),(Object)(main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 100)))),(Object)(main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 60)))));
 BA.debugLineNum = 51;BA.debugLine="End Sub";
Debug.ShouldStop(262144);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _activity_pause(RemoteObject _userclosed) throws Exception{
try {
		Debug.PushSubsStack("Activity_Pause (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,57);
if (RapidSub.canDelegate("activity_pause")) return main.remoteMe.runUserSub(false, "main","activity_pause", _userclosed);
Debug.locals.put("UserClosed", _userclosed);
 BA.debugLineNum = 57;BA.debugLine="Sub Activity_Pause (UserClosed As Boolean)";
Debug.ShouldStop(16777216);
 BA.debugLineNum = 59;BA.debugLine="End Sub";
Debug.ShouldStop(67108864);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _activity_resume() throws Exception{
try {
		Debug.PushSubsStack("Activity_Resume (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,53);
if (RapidSub.canDelegate("activity_resume")) return main.remoteMe.runUserSub(false, "main","activity_resume");
 BA.debugLineNum = 53;BA.debugLine="Sub Activity_Resume";
Debug.ShouldStop(1048576);
 BA.debugLineNum = 55;BA.debugLine="End Sub";
Debug.ShouldStop(4194304);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _globals() throws Exception{
 //BA.debugLineNum = 18;BA.debugLine="Sub Globals";
 //BA.debugLineNum = 21;BA.debugLine="Private lblTitle, lblPanelTitle As Label";
main.mostCurrent._lbltitle = RemoteObject.createNew ("anywheresoftware.b4a.objects.LabelWrapper");
main.mostCurrent._lblpaneltitle = RemoteObject.createNew ("anywheresoftware.b4a.objects.LabelWrapper");
 //BA.debugLineNum = 22;BA.debugLine="Private pnlTest As Panel";
main.mostCurrent._pnltest = RemoteObject.createNew ("anywheresoftware.b4a.objects.PanelWrapper");
 //BA.debugLineNum = 23;BA.debugLine="Private btnTest As Button";
main.mostCurrent._btntest = RemoteObject.createNew ("anywheresoftware.b4a.objects.ButtonWrapper");
 //BA.debugLineNum = 24;BA.debugLine="End Sub";
return RemoteObject.createImmutable("");
}

public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        main_subs_0._process_globals();
main.myClass = BA.getDeviceClass ("B4A.AddViewsByCode.main");
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}public static RemoteObject  _process_globals() throws Exception{
 //BA.debugLineNum = 12;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 16;BA.debugLine="End Sub";
return RemoteObject.createImmutable("");
}
}