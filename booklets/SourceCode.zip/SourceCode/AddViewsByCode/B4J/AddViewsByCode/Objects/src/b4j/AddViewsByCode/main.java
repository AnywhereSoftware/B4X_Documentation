package b4j.AddViewsByCode;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.debug.*;

public class main extends javafx.application.Application{
public static main mostCurrent = new main();

public static BA ba;
static {
		ba = new  anywheresoftware.b4j.objects.FxBA("b4j.AddViewsByCode", "b4j.AddViewsByCode.main", null);
		ba.loadHtSubs(main.class);
        if (ba.getClass().getName().endsWith("ShellBA")) {
			
			ba.raiseEvent2(null, true, "SHELL", false);
			ba.raiseEvent2(null, true, "CREATE", true, "b4j.AddViewsByCode.main", ba);
		}
	}
    public static Class<?> getObject() {
		return main.class;
	}

 
    public static void main(String[] args) {
    	launch(args);
    }
    public void start (javafx.stage.Stage stage) {
        try {
            if (!false)
                System.setProperty("prism.lcdtext", "false");
            anywheresoftware.b4j.objects.FxBA.application = this;
		    anywheresoftware.b4a.keywords.Common.setDensity(javafx.stage.Screen.getPrimary().getDpi());
            anywheresoftware.b4a.keywords.Common.LogDebug("Program started.");
            initializeProcessGlobals();
            anywheresoftware.b4j.objects.Form frm = new anywheresoftware.b4j.objects.Form();
            frm.initWithStage(ba, stage, 600, 400);
            ba.raiseEvent(null, "appstart", frm, (String[])getParameters().getRaw().toArray(new String[0]));
        } catch (Throwable t) {
            BA.printException(t, true);
            System.exit(1);
        }
    }
public static anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4j.objects.JFX _fx = null;
public static anywheresoftware.b4j.objects.Form _mainform = null;
public static anywheresoftware.b4j.objects.LabelWrapper _lbltitle = null;
public static anywheresoftware.b4j.objects.LabelWrapper _lblpaneltitle = null;
public static anywheresoftware.b4j.objects.PaneWrapper.ConcretePaneWrapper _pnltest = null;
public static anywheresoftware.b4j.objects.PaneWrapper.ConcretePaneWrapper _pnltools = null;
public static anywheresoftware.b4j.objects.ButtonWrapper _btncut = null;
public static anywheresoftware.b4j.objects.ButtonWrapper _btncopy = null;
public static anywheresoftware.b4j.objects.ButtonWrapper _btnpaste = null;
public static b4j.example.cssutils _cssutils = null;
public static String  _appstart(anywheresoftware.b4j.objects.Form _form1,String[] _args) throws Exception{
 //BA.debugLineNum = 15;BA.debugLine="Sub AppStart (Form1 As Form, Args() As String)";
 //BA.debugLineNum = 16;BA.debugLine="MainForm = Form1";
_mainform = _form1;
 //BA.debugLineNum = 17;BA.debugLine="MainForm.Title = \"Add views by code\"";
_mainform.setTitle("Add views by code");
 //BA.debugLineNum = 18;BA.debugLine="MainForm.Resizable = True";
_mainform.setResizable(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 21;BA.debugLine="MainForm.SetWindowSizeLimits(310, 300, 1200, 800)";
_mainform.SetWindowSizeLimits(310,300,1200,800);
 //BA.debugLineNum = 24;BA.debugLine="lblTitle.Initialize(\"\")";
_lbltitle.Initialize(ba,"");
 //BA.debugLineNum = 25;BA.debugLine="CSSUtils.SetBackgroundColor(lblTitle, fx.Colors.R";
_cssutils._setbackgroundcolor((anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper(), (javafx.scene.Node)(_lbltitle.getObject())),(anywheresoftware.b4j.objects.JFX.PaintWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.JFX.PaintWrapper(), (javafx.scene.paint.Paint)(_fx.Colors.Red)));
 //BA.debugLineNum = 26;BA.debugLine="lblTitle.TextSize = 20";
_lbltitle.setTextSize(20);
 //BA.debugLineNum = 27;BA.debugLine="lblTitle.TextColor = fx.Colors.White";
_lbltitle.setTextColor(_fx.Colors.White);
 //BA.debugLineNum = 28;BA.debugLine="lblTitle.Alignment = \"CENTER\"";
_lbltitle.setAlignment("CENTER");
 //BA.debugLineNum = 29;BA.debugLine="lblTitle.Text = \"Title\"";
_lbltitle.setText("Title");
 //BA.debugLineNum = 31;BA.debugLine="pnlTest.Initialize(\"\")";
_pnltest.Initialize(ba,"");
 //BA.debugLineNum = 32;BA.debugLine="CSSUtils.SetBackgroundColor(pnlTest, fx.Colors.RG";
_cssutils._setbackgroundcolor((anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper(), (javafx.scene.Node)(_pnltest.getObject())),(anywheresoftware.b4j.objects.JFX.PaintWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.JFX.PaintWrapper(), (javafx.scene.paint.Paint)(_fx.Colors.RGB((int) (240),(int) (255),(int) (240)))));
 //BA.debugLineNum = 33;BA.debugLine="CSSUtils.SetBorder(pnlTest, 1, fx.Colors.Black, 0";
_cssutils._setborder((anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper(), (javafx.scene.Node)(_pnltest.getObject())),1,(anywheresoftware.b4j.objects.JFX.PaintWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.JFX.PaintWrapper(), (javafx.scene.paint.Paint)(_fx.Colors.Black)),0);
 //BA.debugLineNum = 35;BA.debugLine="pnlTools.Initialize(\"\")";
_pnltools.Initialize(ba,"");
 //BA.debugLineNum = 36;BA.debugLine="CSSUtils.SetBackgroundColor(pnlTools, fx.Colors.B";
_cssutils._setbackgroundcolor((anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper(), (javafx.scene.Node)(_pnltools.getObject())),(anywheresoftware.b4j.objects.JFX.PaintWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.JFX.PaintWrapper(), (javafx.scene.paint.Paint)(_fx.Colors.Blue)));
 //BA.debugLineNum = 38;BA.debugLine="btnCut.Initialize(\"btnCut\")";
_btncut.Initialize(ba,"btnCut");
 //BA.debugLineNum = 39;BA.debugLine="CSSUtils.SetBackgroundColor(btnCut, fx.Colors.RGB";
_cssutils._setbackgroundcolor((anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper(), (javafx.scene.Node)(_btncut.getObject())),(anywheresoftware.b4j.objects.JFX.PaintWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.JFX.PaintWrapper(), (javafx.scene.paint.Paint)(_fx.Colors.RGB((int) (0),(int) (255),(int) (255)))));
 //BA.debugLineNum = 40;BA.debugLine="btnCut.Text = \"Cut\"";
_btncut.setText("Cut");
 //BA.debugLineNum = 42;BA.debugLine="btnCopy.Initialize(\"btnCopy\")";
_btncopy.Initialize(ba,"btnCopy");
 //BA.debugLineNum = 43;BA.debugLine="CSSUtils.SetBackgroundColor(btnCopy, fx.Colors.RG";
_cssutils._setbackgroundcolor((anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper(), (javafx.scene.Node)(_btncopy.getObject())),(anywheresoftware.b4j.objects.JFX.PaintWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.JFX.PaintWrapper(), (javafx.scene.paint.Paint)(_fx.Colors.RGB((int) (0),(int) (255),(int) (255)))));
 //BA.debugLineNum = 44;BA.debugLine="btnCopy.Text = \"Copy\"";
_btncopy.setText("Copy");
 //BA.debugLineNum = 46;BA.debugLine="btnPaste.Initialize(\"btnPaste\")";
_btnpaste.Initialize(ba,"btnPaste");
 //BA.debugLineNum = 47;BA.debugLine="CSSUtils.SetBackgroundColor(btnPaste, fx.Colors.R";
_cssutils._setbackgroundcolor((anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper(), (javafx.scene.Node)(_btnpaste.getObject())),(anywheresoftware.b4j.objects.JFX.PaintWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.JFX.PaintWrapper(), (javafx.scene.paint.Paint)(_fx.Colors.RGB((int) (0),(int) (255),(int) (255)))));
 //BA.debugLineNum = 48;BA.debugLine="btnPaste.Text = \"Paste\"";
_btnpaste.setText("Paste");
 //BA.debugLineNum = 50;BA.debugLine="lblPanelTitle.Initialize(\"\")";
_lblpaneltitle.Initialize(ba,"");
 //BA.debugLineNum = 51;BA.debugLine="CSSUtils.SetBackgroundColor(lblPanelTitle, fx.Col";
_cssutils._setbackgroundcolor((anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper(), (javafx.scene.Node)(_lblpaneltitle.getObject())),(anywheresoftware.b4j.objects.JFX.PaintWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.JFX.PaintWrapper(), (javafx.scene.paint.Paint)(_fx.Colors.Red)));
 //BA.debugLineNum = 52;BA.debugLine="lblPanelTitle.TextSize = 16";
_lblpaneltitle.setTextSize(16);
 //BA.debugLineNum = 53;BA.debugLine="lblPanelTitle.TextColor = fx.Colors.White";
_lblpaneltitle.setTextColor(_fx.Colors.White);
 //BA.debugLineNum = 54;BA.debugLine="lblPanelTitle.Alignment = \"CENTER\"";
_lblpaneltitle.setAlignment("CENTER");
 //BA.debugLineNum = 55;BA.debugLine="lblPanelTitle.Text = \"Panel test\"";
_lblpaneltitle.setText("Panel test");
 //BA.debugLineNum = 56;BA.debugLine="MainForm.RootPane.AddNode(lblTitle, 20, 20, 400,";
_mainform.getRootPane().AddNode((javafx.scene.Node)(_lbltitle.getObject()),20,20,400,30);
 //BA.debugLineNum = 57;BA.debugLine="MainForm.RootPane.AddNode(pnlTest, 20, 20, 50, 50";
_mainform.getRootPane().AddNode((javafx.scene.Node)(_pnltest.getObject()),20,20,50,50);
 //BA.debugLineNum = 58;BA.debugLine="MainForm.RootPane.AddNode(pnlTools, 10, 10, 50, 6";
_mainform.getRootPane().AddNode((javafx.scene.Node)(_pnltools.getObject()),10,10,50,60);
 //BA.debugLineNum = 59;BA.debugLine="pnlTest.AddNode(lblPanelTitle, 20, 10, 100, 30)";
_pnltest.AddNode((javafx.scene.Node)(_lblpaneltitle.getObject()),20,10,100,30);
 //BA.debugLineNum = 60;BA.debugLine="pnlTools.AddNode(btnCut, 50, 10, 70, 40)";
_pnltools.AddNode((javafx.scene.Node)(_btncut.getObject()),50,10,70,40);
 //BA.debugLineNum = 61;BA.debugLine="pnlTools.AddNode(btnCopy, 50, 10, 70, 40)";
_pnltools.AddNode((javafx.scene.Node)(_btncopy.getObject()),50,10,70,40);
 //BA.debugLineNum = 62;BA.debugLine="pnlTools.AddNode(btnPaste, 50, 10, 70, 40)";
_pnltools.AddNode((javafx.scene.Node)(_btnpaste.getObject()),50,10,70,40);
 //BA.debugLineNum = 64;BA.debugLine="MainForm.Show";
_mainform.Show();
 //BA.debugLineNum = 65;BA.debugLine="End Sub";
return "";
}
public static String  _mainform_resize(double _width,double _height) throws Exception{
 //BA.debugLineNum = 67;BA.debugLine="Private Sub MainForm_Resize (Width As Double, Heig";
 //BA.debugLineNum = 68;BA.debugLine="lblTitle.Left = 20";
_lbltitle.setLeft(20);
 //BA.debugLineNum = 69;BA.debugLine="lblTitle.SetSize(Width - 40, 30)";
_lbltitle.SetSize(_width-40,30);
 //BA.debugLineNum = 71;BA.debugLine="pnlTools.Left = 0";
_pnltools.setLeft(0);
 //BA.debugLineNum = 72;BA.debugLine="pnlTools.SetSize(Width, 60)";
_pnltools.SetSize(_width,60);
 //BA.debugLineNum = 73;BA.debugLine="pnlTools.Top = Height - pnlTools.Height";
_pnltools.setTop(_height-_pnltools.getHeight());
 //BA.debugLineNum = 75;BA.debugLine="pnlTest.Left = lblTitle.Left";
_pnltest.setLeft(_lbltitle.getLeft());
 //BA.debugLineNum = 76;BA.debugLine="pnlTest.Top = lblTitle.Top + lblTitle.Height + 20";
_pnltest.setTop(_lbltitle.getTop()+_lbltitle.getHeight()+20);
 //BA.debugLineNum = 77;BA.debugLine="pnlTest.SetSize(Width - 40, pnlTools.Top - lblTit";
_pnltest.SetSize(_width-40,_pnltools.getTop()-_lbltitle.getHeight()-60);
 //BA.debugLineNum = 79;BA.debugLine="lblPanelTitle.Left = 20";
_lblpaneltitle.setLeft(20);
 //BA.debugLineNum = 80;BA.debugLine="lblPanelTitle.SetSize(Width - 80, 30)";
_lblpaneltitle.SetSize(_width-80,30);
 //BA.debugLineNum = 82;BA.debugLine="btnCopy.Left = (Width - btnCopy.Width) / 2";
_btncopy.setLeft((_width-_btncopy.getWidth())/(double)2);
 //BA.debugLineNum = 83;BA.debugLine="btnCut.Left = btnCopy.Left - btnCut.Width - 20";
_btncut.setLeft(_btncopy.getLeft()-_btncut.getWidth()-20);
 //BA.debugLineNum = 84;BA.debugLine="btnPaste.Left = btnCopy.Left + btnCut.Width + 20";
_btnpaste.setLeft(_btncopy.getLeft()+_btncut.getWidth()+20);
 //BA.debugLineNum = 85;BA.debugLine="End Sub";
return "";
}

private static boolean processGlobalsRun;
public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        b4j.example.cssutils._process_globals();
main._process_globals();
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 7;BA.debugLine="Private fx As JFX";
_fx = new anywheresoftware.b4j.objects.JFX();
 //BA.debugLineNum = 8;BA.debugLine="Private MainForm As Form";
_mainform = new anywheresoftware.b4j.objects.Form();
 //BA.debugLineNum = 10;BA.debugLine="Private lblTitle, lblPanelTitle As Label";
_lbltitle = new anywheresoftware.b4j.objects.LabelWrapper();
_lblpaneltitle = new anywheresoftware.b4j.objects.LabelWrapper();
 //BA.debugLineNum = 11;BA.debugLine="Private pnlTest, pnlTools As Pane";
_pnltest = new anywheresoftware.b4j.objects.PaneWrapper.ConcretePaneWrapper();
_pnltools = new anywheresoftware.b4j.objects.PaneWrapper.ConcretePaneWrapper();
 //BA.debugLineNum = 12;BA.debugLine="Private btnCut, btnCopy, btnPaste As Button";
_btncut = new anywheresoftware.b4j.objects.ButtonWrapper();
_btncopy = new anywheresoftware.b4j.objects.ButtonWrapper();
_btnpaste = new anywheresoftware.b4j.objects.ButtonWrapper();
 //BA.debugLineNum = 13;BA.debugLine="End Sub";
return "";
}
}
