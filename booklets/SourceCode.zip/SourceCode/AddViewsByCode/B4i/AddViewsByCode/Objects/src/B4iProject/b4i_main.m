
#import "b4i_main.h"


@implementation b4i_main 


+ (instancetype)new {
    static b4i_main* shared = nil;
    if (shared == nil) {
        shared = [self alloc];
        shared.bi = [[B4IShellBI alloc] init:shared];
        shared.__c = [B4ICommon new];
    }
    return shared;
}
- (int)debugAppId {
    return 2087294172;
}


- (NSString*)  _application_background{
[B4IRDebugUtils shared].currentModule=@"main";
[B4IRDebugUtils shared].currentLine=196608;
 //BA.debugLineNum = 196608;BA.debugLine="Private Sub Application_Background";
[B4IRDebugUtils shared].currentLine=196610;
 //BA.debugLineNum = 196610;BA.debugLine="End Sub";
return @"";
}
- (NSString*)  _application_start:(B4INavigationControllerWrapper*) _nav{
[B4IRDebugUtils shared].currentModule=@"main";
[B4IRDebugUtils shared].currentLine=65536;
 //BA.debugLineNum = 65536;BA.debugLine="Private Sub Application_Start (Nav As NavigationController)";
[B4IRDebugUtils shared].currentLine=65537;
 //BA.debugLineNum = 65537;BA.debugLine="NavControl = Nav";
self._navcontrol = _nav;
[B4IRDebugUtils shared].currentLine=65538;
 //BA.debugLineNum = 65538;BA.debugLine="Page1.Initialize(\"Page1\")";
[self._page1 Initialize:self.bi :@"Page1"];
[B4IRDebugUtils shared].currentLine=65539;
 //BA.debugLineNum = 65539;BA.debugLine="Page1.Title = \"Page 1\"";
[self._page1 setTitle:@"Page 1"];
[B4IRDebugUtils shared].currentLine=65540;
 //BA.debugLineNum = 65540;BA.debugLine="Page1.RootPanel.Color = Colors.White";
[[self._page1 RootPanel] setColor:[[self.__c Colors] White]];
[B4IRDebugUtils shared].currentLine=65541;
 //BA.debugLineNum = 65541;BA.debugLine="NavControl.ShowPage(Page1)";
[self._navcontrol ShowPage:(UIViewController*)((self._page1).object)];
[B4IRDebugUtils shared].currentLine=65543;
 //BA.debugLineNum = 65543;BA.debugLine="lblTitle.Initialize(\"\")";
[self._lbltitle Initialize:self.bi :@""];
[B4IRDebugUtils shared].currentLine=65544;
 //BA.debugLineNum = 65544;BA.debugLine="lblTitle.Color = Colors.Red";
[self._lbltitle setColor:[[self.__c Colors] Red]];
[B4IRDebugUtils shared].currentLine=65545;
 //BA.debugLineNum = 65545;BA.debugLine="lblTitle.Font = Font.CreateNew(20)";
[self._lbltitle setFont:[[self.__c Font] CreateNew:(float) (20)]];
[B4IRDebugUtils shared].currentLine=65546;
 //BA.debugLineNum = 65546;BA.debugLine="lblTitle.TextColor = Colors.Blue";
[self._lbltitle setTextColor:[[self.__c Colors] Blue]];
[B4IRDebugUtils shared].currentLine=65547;
 //BA.debugLineNum = 65547;BA.debugLine="lblTitle.TextAlignment =lblTitle.ALIGNMENT_CENTER";
[self._lbltitle setTextAlignment:[self._lbltitle ALIGNMENT_CENTER]];
[B4IRDebugUtils shared].currentLine=65548;
 //BA.debugLineNum = 65548;BA.debugLine="lblTitle.Text = \"Title\"";
[self._lbltitle setText:@"Title"];
[B4IRDebugUtils shared].currentLine=65550;
 //BA.debugLineNum = 65550;BA.debugLine="pnlTest.Initialize(\"\")";
[self._pnltest Initialize:self.bi :@""];
[B4IRDebugUtils shared].currentLine=65551;
 //BA.debugLineNum = 65551;BA.debugLine="pnlTest.Color = Colors.LightGray";
[self._pnltest setColor:[[self.__c Colors] LightGray]];
[B4IRDebugUtils shared].currentLine=65553;
 //BA.debugLineNum = 65553;BA.debugLine="btnTest.InitializeCustom(\"btnTest\", Colors.Black, Colors.Blue)";
[self._btntest InitializeCustom:@"btnTest" :self.bi :[[self.__c Colors] Black] :[[self.__c Colors] Blue]];
[B4IRDebugUtils shared].currentLine=65554;
 //BA.debugLineNum = 65554;BA.debugLine="btnTest.SetBorder(1, Colors.Black, 5)";
[self._btntest SetBorder:(float) (1) :[[self.__c Colors] Black] :(float) (5)];
[B4IRDebugUtils shared].currentLine=65555;
 //BA.debugLineNum = 65555;BA.debugLine="btnTest.Text = \"Test\"";
[self._btntest setText:@"Test"];
[B4IRDebugUtils shared].currentLine=65557;
 //BA.debugLineNum = 65557;BA.debugLine="lblPanelTitle.Initialize(\"\")";
[self._lblpaneltitle Initialize:self.bi :@""];
[B4IRDebugUtils shared].currentLine=65558;
 //BA.debugLineNum = 65558;BA.debugLine="lblPanelTitle.Color = Colors.Red";
[self._lblpaneltitle setColor:[[self.__c Colors] Red]];
[B4IRDebugUtils shared].currentLine=65559;
 //BA.debugLineNum = 65559;BA.debugLine="lblPanelTitle.Font = Font.CreateNew(16)";
[self._lblpaneltitle setFont:[[self.__c Font] CreateNew:(float) (16)]];
[B4IRDebugUtils shared].currentLine=65560;
 //BA.debugLineNum = 65560;BA.debugLine="lblPanelTitle.TextColor = Colors.Blue";
[self._lblpaneltitle setTextColor:[[self.__c Colors] Blue]];
[B4IRDebugUtils shared].currentLine=65561;
 //BA.debugLineNum = 65561;BA.debugLine="lblPanelTitle.TextAlignment = lblPanelTitle.ALIGNMENT_CENTER";
[self._lblpaneltitle setTextAlignment:[self._lblpaneltitle ALIGNMENT_CENTER]];
[B4IRDebugUtils shared].currentLine=65562;
 //BA.debugLineNum = 65562;BA.debugLine="lblPanelTitle.Text = \"Panel test\"";
[self._lblpaneltitle setText:@"Panel test"];
[B4IRDebugUtils shared].currentLine=65563;
 //BA.debugLineNum = 65563;BA.debugLine="End Sub";
return @"";
}
- (NSString*)  _page1_resize:(int) _width :(int) _height{
[B4IRDebugUtils shared].currentModule=@"main";
[B4IRDebugUtils shared].currentLine=131072;
 //BA.debugLineNum = 131072;BA.debugLine="Private Sub Page1_Resize(Width As Int, Height As Int)";
[B4IRDebugUtils shared].currentLine=131073;
 //BA.debugLineNum = 131073;BA.debugLine="Page1.RootPanel.AddView(lblTitle, 20%x, 10, 60%x, 30)";
[[self._page1 RootPanel] AddView:(UIView*)((self._lbltitle).object) :[self.__c PerXToCurrent:(float) (20)] :(float) (10) :[self.__c PerXToCurrent:(float) (60)] :(float) (30)];
[B4IRDebugUtils shared].currentLine=131074;
 //BA.debugLineNum = 131074;BA.debugLine="Page1.RootPanel.AddView(pnlTest, 10%x, lblTitle.Top + lblTitle.Height + 10, 80%x, 30%y)";
[[self._page1 RootPanel] AddView:(UIView*)((self._pnltest).object) :[self.__c PerXToCurrent:(float) (10)] :(float) ([self._lbltitle Top]+[self._lbltitle Height]+10) :[self.__c PerXToCurrent:(float) (80)] :[self.__c PerYToCurrent:(float) (30)]];
[B4IRDebugUtils shared].currentLine=131075;
 //BA.debugLineNum = 131075;BA.debugLine="pnlTest.AddView(lblPanelTitle, 20, 10, 100, 30)";
[self._pnltest AddView:(UIView*)((self._lblpaneltitle).object) :(float) (20) :(float) (10) :(float) (100) :(float) (30)];
[B4IRDebugUtils shared].currentLine=131076;
 //BA.debugLineNum = 131076;BA.debugLine="pnlTest.AddView(btnTest, 50, 50, 100, 60)";
[self._pnltest AddView:(UIView*)((self._btntest).object) :(float) (50) :(float) (50) :(float) (100) :(float) (60)];
[B4IRDebugUtils shared].currentLine=131077;
 //BA.debugLineNum = 131077;BA.debugLine="End Sub";
return @"";
}

- (void)initializeStaticModules {
    [[b4i_main new]initializeModule];

}
- (NSString*)  _process_globals{
[B4IRDebugUtils shared].currentModule=@"main";
[B4IRDebugUtils shared].currentLine=0;
 //BA.debugLineNum = 0;BA.debugLine="Sub Process_Globals";
return @"";
}
@end