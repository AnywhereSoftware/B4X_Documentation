package anywheresoftware.b4i.addviewsbycode;

import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.pc.*;

public class b4i_main_subs_0 {


public static RemoteObject  _application_background() throws Exception{
try {
		Debug.PushSubsStack("Application_Background (main) ","main",0,b4i_main.ba,b4i_main.mostCurrent,56);
if (RapidSub.canDelegate("application_background")) return b4i_main.remoteMe.runUserSub(false, "main","application_background");
 BA.debugLineNum = 56;BA.debugLine="Private Sub Application_Background";
Debug.ShouldStop(8388608);
 BA.debugLineNum = 58;BA.debugLine="End Sub";
Debug.ShouldStop(33554432);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _application_start(RemoteObject _nav) throws Exception{
try {
		Debug.PushSubsStack("Application_Start (main) ","main",0,b4i_main.ba,b4i_main.mostCurrent,20);
if (RapidSub.canDelegate("application_start")) return b4i_main.remoteMe.runUserSub(false, "main","application_start", _nav);
Debug.locals.put("Nav", _nav);
 BA.debugLineNum = 20;BA.debugLine="Private Sub Application_Start (Nav As NavigationController)";
Debug.ShouldStop(524288);
 BA.debugLineNum = 21;BA.debugLine="NavControl = Nav";
Debug.ShouldStop(1048576);
b4i_main._navcontrol = _nav;
 BA.debugLineNum = 22;BA.debugLine="Page1.Initialize(\"Page1\")";
Debug.ShouldStop(2097152);
b4i_main._page1.runVoidMethod ("Initialize::",b4i_main.ba,(Object)(BA.ObjectToString("Page1")));
 BA.debugLineNum = 23;BA.debugLine="Page1.Title = \"Page 1\"";
Debug.ShouldStop(4194304);
b4i_main._page1.runMethod(true,"setTitle:",BA.ObjectToString("Page 1"));
 BA.debugLineNum = 24;BA.debugLine="Page1.RootPanel.Color = Colors.White";
Debug.ShouldStop(8388608);
b4i_main._page1.runMethod(false,"RootPanel").runMethod(true,"setColor:",b4i_main.__c.runMethod(false,"Colors").runMethod(true,"White"));
 BA.debugLineNum = 25;BA.debugLine="NavControl.ShowPage(Page1)";
Debug.ShouldStop(16777216);
b4i_main._navcontrol.runVoidMethod ("ShowPage:",(Object)(((b4i_main._page1).getObject())));
 BA.debugLineNum = 27;BA.debugLine="lblTitle.Initialize(\"\")";
Debug.ShouldStop(67108864);
b4i_main._lbltitle.runVoidMethod ("Initialize::",b4i_main.ba,(Object)(BA.ObjectToString("")));
 BA.debugLineNum = 28;BA.debugLine="lblTitle.Color = Colors.Red";
Debug.ShouldStop(134217728);
b4i_main._lbltitle.runMethod(true,"setColor:",b4i_main.__c.runMethod(false,"Colors").runMethod(true,"Red"));
 BA.debugLineNum = 29;BA.debugLine="lblTitle.Font = Font.CreateNew(20)";
Debug.ShouldStop(268435456);
b4i_main._lbltitle.runMethod(false,"setFont:",b4i_main.__c.runMethod(false,"Font").runMethod(false,"CreateNew:",(Object)(BA.numberCast(float.class, 20))));
 BA.debugLineNum = 30;BA.debugLine="lblTitle.TextColor = Colors.Blue";
Debug.ShouldStop(536870912);
b4i_main._lbltitle.runMethod(true,"setTextColor:",b4i_main.__c.runMethod(false,"Colors").runMethod(true,"Blue"));
 BA.debugLineNum = 31;BA.debugLine="lblTitle.TextAlignment =lblTitle.ALIGNMENT_CENTER";
Debug.ShouldStop(1073741824);
b4i_main._lbltitle.runMethod(true,"setTextAlignment:",b4i_main._lbltitle.runMethod(true,"ALIGNMENT_CENTER"));
 BA.debugLineNum = 32;BA.debugLine="lblTitle.Text = \"Title\"";
Debug.ShouldStop(-2147483648);
b4i_main._lbltitle.runMethod(true,"setText:",BA.ObjectToString("Title"));
 BA.debugLineNum = 34;BA.debugLine="pnlTest.Initialize(\"\")";
Debug.ShouldStop(2);
b4i_main._pnltest.runVoidMethod ("Initialize::",b4i_main.ba,(Object)(BA.ObjectToString("")));
 BA.debugLineNum = 35;BA.debugLine="pnlTest.Color = Colors.LightGray";
Debug.ShouldStop(4);
b4i_main._pnltest.runMethod(true,"setColor:",b4i_main.__c.runMethod(false,"Colors").runMethod(true,"LightGray"));
 BA.debugLineNum = 37;BA.debugLine="btnTest.InitializeCustom(\"btnTest\", Colors.Black, Colors.Blue)";
Debug.ShouldStop(16);
b4i_main._btntest.runVoidMethod ("InitializeCustom::::",(Object)(BA.ObjectToString("btnTest")),b4i_main.ba,(Object)(b4i_main.__c.runMethod(false,"Colors").runMethod(true,"Black")),(Object)(b4i_main.__c.runMethod(false,"Colors").runMethod(true,"Blue")));
 BA.debugLineNum = 38;BA.debugLine="btnTest.SetBorder(1, Colors.Black, 5)";
Debug.ShouldStop(32);
b4i_main._btntest.runVoidMethod ("SetBorder:::",(Object)(BA.numberCast(float.class, 1)),(Object)(b4i_main.__c.runMethod(false,"Colors").runMethod(true,"Black")),(Object)(BA.numberCast(float.class, 5)));
 BA.debugLineNum = 39;BA.debugLine="btnTest.Text = \"Test\"";
Debug.ShouldStop(64);
b4i_main._btntest.runMethod(true,"setText:",BA.ObjectToString("Test"));
 BA.debugLineNum = 41;BA.debugLine="lblPanelTitle.Initialize(\"\")";
Debug.ShouldStop(256);
b4i_main._lblpaneltitle.runVoidMethod ("Initialize::",b4i_main.ba,(Object)(BA.ObjectToString("")));
 BA.debugLineNum = 42;BA.debugLine="lblPanelTitle.Color = Colors.Red";
Debug.ShouldStop(512);
b4i_main._lblpaneltitle.runMethod(true,"setColor:",b4i_main.__c.runMethod(false,"Colors").runMethod(true,"Red"));
 BA.debugLineNum = 43;BA.debugLine="lblPanelTitle.Font = Font.CreateNew(16)";
Debug.ShouldStop(1024);
b4i_main._lblpaneltitle.runMethod(false,"setFont:",b4i_main.__c.runMethod(false,"Font").runMethod(false,"CreateNew:",(Object)(BA.numberCast(float.class, 16))));
 BA.debugLineNum = 44;BA.debugLine="lblPanelTitle.TextColor = Colors.Blue";
Debug.ShouldStop(2048);
b4i_main._lblpaneltitle.runMethod(true,"setTextColor:",b4i_main.__c.runMethod(false,"Colors").runMethod(true,"Blue"));
 BA.debugLineNum = 45;BA.debugLine="lblPanelTitle.TextAlignment = lblPanelTitle.ALIGNMENT_CENTER";
Debug.ShouldStop(4096);
b4i_main._lblpaneltitle.runMethod(true,"setTextAlignment:",b4i_main._lblpaneltitle.runMethod(true,"ALIGNMENT_CENTER"));
 BA.debugLineNum = 46;BA.debugLine="lblPanelTitle.Text = \"Panel test\"";
Debug.ShouldStop(8192);
b4i_main._lblpaneltitle.runMethod(true,"setText:",BA.ObjectToString("Panel test"));
 BA.debugLineNum = 47;BA.debugLine="End Sub";
Debug.ShouldStop(16384);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _page1_resize(RemoteObject _width,RemoteObject _height) throws Exception{
try {
		Debug.PushSubsStack("Page1_Resize (main) ","main",0,b4i_main.ba,b4i_main.mostCurrent,49);
if (RapidSub.canDelegate("page1_resize")) return b4i_main.remoteMe.runUserSub(false, "main","page1_resize", _width, _height);
Debug.locals.put("Width", _width);
Debug.locals.put("Height", _height);
 BA.debugLineNum = 49;BA.debugLine="Private Sub Page1_Resize(Width As Int, Height As Int)";
Debug.ShouldStop(65536);
 BA.debugLineNum = 50;BA.debugLine="Page1.RootPanel.AddView(lblTitle, 20%x, 10, 60%x, 30)";
Debug.ShouldStop(131072);
b4i_main._page1.runMethod(false,"RootPanel").runVoidMethod ("AddView:::::",(Object)(((b4i_main._lbltitle).getObject())),(Object)(b4i_main.__c.runMethod(true,"PerXToCurrent:",(Object)(BA.numberCast(float.class, 20)))),(Object)(BA.numberCast(float.class, 10)),(Object)(b4i_main.__c.runMethod(true,"PerXToCurrent:",(Object)(BA.numberCast(float.class, 60)))),(Object)(BA.numberCast(float.class, 30)));
 BA.debugLineNum = 51;BA.debugLine="Page1.RootPanel.AddView(pnlTest, 10%x, lblTitle.Top + lblTitle.Height + 10, 80%x, 30%y)";
Debug.ShouldStop(262144);
b4i_main._page1.runMethod(false,"RootPanel").runVoidMethod ("AddView:::::",(Object)(((b4i_main._pnltest).getObject())),(Object)(b4i_main.__c.runMethod(true,"PerXToCurrent:",(Object)(BA.numberCast(float.class, 10)))),(Object)(BA.numberCast(float.class, RemoteObject.solve(new RemoteObject[] {b4i_main._lbltitle.runMethod(true,"Top"),b4i_main._lbltitle.runMethod(true,"Height"),RemoteObject.createImmutable(10)}, "++",2, 0))),(Object)(b4i_main.__c.runMethod(true,"PerXToCurrent:",(Object)(BA.numberCast(float.class, 80)))),(Object)(b4i_main.__c.runMethod(true,"PerYToCurrent:",(Object)(BA.numberCast(float.class, 30)))));
 BA.debugLineNum = 52;BA.debugLine="pnlTest.AddView(lblPanelTitle, 20, 10, 100, 30)";
Debug.ShouldStop(524288);
b4i_main._pnltest.runVoidMethod ("AddView:::::",(Object)(((b4i_main._lblpaneltitle).getObject())),(Object)(BA.numberCast(float.class, 20)),(Object)(BA.numberCast(float.class, 10)),(Object)(BA.numberCast(float.class, 100)),(Object)(BA.numberCast(float.class, 30)));
 BA.debugLineNum = 53;BA.debugLine="pnlTest.AddView(btnTest, 50, 50, 100, 60)";
Debug.ShouldStop(1048576);
b4i_main._pnltest.runVoidMethod ("AddView:::::",(Object)(((b4i_main._btntest).getObject())),(Object)(BA.numberCast(float.class, 50)),(Object)(BA.numberCast(float.class, 50)),(Object)(BA.numberCast(float.class, 100)),(Object)(BA.numberCast(float.class, 60)));
 BA.debugLineNum = 54;BA.debugLine="End Sub";
Debug.ShouldStop(2097152);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _process_globals() throws Exception{
 //BA.debugLineNum = 10;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 11;BA.debugLine="Public App As Application";
b4i_main._app = RemoteObject.createNew("B4IApplicationWrapper");
 //BA.debugLineNum = 12;BA.debugLine="Public NavControl As NavigationController";
b4i_main._navcontrol = RemoteObject.createNew("B4INavigationControllerWrapper");
 //BA.debugLineNum = 13;BA.debugLine="Private Page1 As Page";
b4i_main._page1 = RemoteObject.createNew("B4IPage");
 //BA.debugLineNum = 15;BA.debugLine="Private lblTitle, lblPanelTitle As Label";
b4i_main._lbltitle = RemoteObject.createNew("B4ILabelWrapper");
b4i_main._lblpaneltitle = RemoteObject.createNew("B4ILabelWrapper");
 //BA.debugLineNum = 16;BA.debugLine="Private pnlTest As Panel";
b4i_main._pnltest = RemoteObject.createNew("B4IPanelWrapper");
 //BA.debugLineNum = 17;BA.debugLine="Private btnTest As Button";
b4i_main._btntest = RemoteObject.createNew("B4IButtonWrapper");
 //BA.debugLineNum = 18;BA.debugLine="End Sub";
return RemoteObject.createImmutable("");
}
}