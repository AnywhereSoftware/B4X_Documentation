package b4a.AutoScaleExample1.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_main{

public static void LS_general(java.util.LinkedHashMap<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
//BA.debugLineNum = 4;BA.debugLine="AutoScaleRate(0.5)"[main/General script]
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.5d);
//BA.debugLineNum = 7;BA.debugLine="AutoScaleAll"[main/General script]
anywheresoftware.b4a.keywords.LayoutBuilder.scaleAll(views);
//BA.debugLineNum = 10;BA.debugLine="lblTitle.HorizontalCenter = 50%x"[main/General script]
views.get("lbltitle").vw.setLeft((int)((50d / 100 * width) - (views.get("lbltitle").vw.getWidth() / 2)));
//BA.debugLineNum = 11;BA.debugLine="lblSubTitle.HorizontalCenter = 50%x"[main/General script]
views.get("lblsubtitle").vw.setLeft((int)((50d / 100 * width) - (views.get("lblsubtitle").vw.getWidth() / 2)));
//BA.debugLineNum = 14;BA.debugLine="pnlToolBox.HorizontalCenter = 50%x"[main/General script]
views.get("pnltoolbox").vw.setLeft((int)((50d / 100 * width) - (views.get("pnltoolbox").vw.getWidth() / 2)));
//BA.debugLineNum = 17;BA.debugLine="scvTest.HorizontalCenter = 50%x"[main/General script]
views.get("scvtest").vw.setLeft((int)((50d / 100 * width) - (views.get("scvtest").vw.getWidth() / 2)));

}
}