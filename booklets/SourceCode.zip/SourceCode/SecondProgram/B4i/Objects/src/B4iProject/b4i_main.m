
#import "b4i_main.h"


@implementation b4i_main 


+ (instancetype)new {
    static b4i_main* shared = nil;
    if (shared == nil) {
        shared = [self alloc];
        shared.bi = [[B4IShellBI alloc] init:shared];
        shared.__c = [B4ICommon new];
    }
    return shared;
}
- (int)debugAppId {
    return 39;
}


- (NSString*)  _application_active{
[B4IRDebugUtils shared].currentModule=@"main";
if ([B4IDebug shouldDelegate: @"application_active"])
	return ((NSString*) [B4IDebug delegate:self.bi :@"application_active" :nil]);
[B4IRDebugUtils shared].currentLine=196608;
 //BA.debugLineNum = 196608;BA.debugLine="Private Sub Application_Active";
[B4IRDebugUtils shared].currentLine=196610;
 //BA.debugLineNum = 196610;BA.debugLine="End Sub";
return @"";
}
- (NSString*)  _application_background{
[B4IRDebugUtils shared].currentModule=@"main";
if ([B4IDebug shouldDelegate: @"application_background"])
	return ((NSString*) [B4IDebug delegate:self.bi :@"application_background" :nil]);
[B4IRDebugUtils shared].currentLine=327680;
 //BA.debugLineNum = 327680;BA.debugLine="Private Sub Application_Background";
[B4IRDebugUtils shared].currentLine=327682;
 //BA.debugLineNum = 327682;BA.debugLine="End Sub";
return @"";
}
- (NSString*)  _application_inactive{
[B4IRDebugUtils shared].currentModule=@"main";
if ([B4IDebug shouldDelegate: @"application_inactive"])
	return ((NSString*) [B4IDebug delegate:self.bi :@"application_inactive" :nil]);
[B4IRDebugUtils shared].currentLine=262144;
 //BA.debugLineNum = 262144;BA.debugLine="Private Sub Application_Inactive";
[B4IRDebugUtils shared].currentLine=262146;
 //BA.debugLineNum = 262146;BA.debugLine="End Sub";
return @"";
}
- (NSString*)  _application_start:(B4INavigationControllerWrapper*) _nav{
[B4IRDebugUtils shared].currentModule=@"main";
if ([B4IDebug shouldDelegate: @"application_start"])
	return ((NSString*) [B4IDebug delegate:self.bi :@"application_start:" :@[[B4I nilToNSNull:_nav]]]);
[B4IRDebugUtils shared].currentLine=65536;
 //BA.debugLineNum = 65536;BA.debugLine="Private Sub Application_Start (Nav As NavigationCo";
[B4IRDebugUtils shared].currentLine=65537;
 //BA.debugLineNum = 65537;BA.debugLine="NavControl = Nav";
self._navcontrol = _nav;
[B4IRDebugUtils shared].currentLine=65538;
 //BA.debugLineNum = 65538;BA.debugLine="Page1.Initialize(\"Page1\")";
[self._page1 Initialize:self.bi :@"Page1"];
[B4IRDebugUtils shared].currentLine=65539;
 //BA.debugLineNum = 65539;BA.debugLine="Page1.RootPanel.Color = Colors.White";
[[self._page1 RootPanel] setColor:[[self.__c Colors] White]];
[B4IRDebugUtils shared].currentLine=65540;
 //BA.debugLineNum = 65540;BA.debugLine="Page1.RootPanel.LoadLayout(\"Main\")";
[[self._page1 RootPanel] LoadLayout:@"Main" :self.bi];
[B4IRDebugUtils shared].currentLine=65541;
 //BA.debugLineNum = 65541;BA.debugLine="Page1.Title = \"Calc Trainer\"";
[self._page1 setTitle:@"Calc Trainer"];
[B4IRDebugUtils shared].currentLine=65542;
 //BA.debugLineNum = 65542;BA.debugLine="NavControl.ShowPage(Page1)";
[self._navcontrol ShowPage:(UIViewController*)((self._page1).object)];
[B4IRDebugUtils shared].currentLine=65544;
 //BA.debugLineNum = 65544;BA.debugLine="New";
[self _new];
[B4IRDebugUtils shared].currentLine=65545;
 //BA.debugLineNum = 65545;BA.debugLine="End Sub";
return @"";
}
- (NSString*)  _new{
[B4IRDebugUtils shared].currentModule=@"main";
if ([B4IDebug shouldDelegate: @"new"])
	return ((NSString*) [B4IDebug delegate:self.bi :@"new" :nil]);
[B4IRDebugUtils shared].currentLine=458752;
 //BA.debugLineNum = 458752;BA.debugLine="Private Sub New";
[B4IRDebugUtils shared].currentLine=458753;
 //BA.debugLineNum = 458753;BA.debugLine="Number1 = Rnd(1, 10)				' Generates a random numb";
self._number1 = [self.__c Rnd:(int) (1) :(int) (10)];
[B4IRDebugUtils shared].currentLine=458754;
 //BA.debugLineNum = 458754;BA.debugLine="Number2 = Rnd(1, 10)				' Generates a random numb";
self._number2 = [self.__c Rnd:(int) (1) :(int) (10)];
[B4IRDebugUtils shared].currentLine=458755;
 //BA.debugLineNum = 458755;BA.debugLine="lblNumber1.Text = Number1		' Displays Number1 in";
[self._lblnumber1 setText:[self.bi NumberToString:@(self._number1)]];
[B4IRDebugUtils shared].currentLine=458756;
 //BA.debugLineNum = 458756;BA.debugLine="lblNumber2.Text = Number2		' Displays Number2 in";
[self._lblnumber2 setText:[self.bi NumberToString:@(self._number2)]];
[B4IRDebugUtils shared].currentLine=458757;
 //BA.debugLineNum = 458757;BA.debugLine="lblComments.Text = \"Enter the result\" & CRLF & \"a";
[self._lblcomments setText:[@[@"Enter the result",[self.__c CRLF],@"and click on OK"] componentsJoinedByString:@""]];
[B4IRDebugUtils shared].currentLine=458758;
 //BA.debugLineNum = 458758;BA.debugLine="lblComments.Color = Colors.RGB(255,235,128)	' yel";
[self._lblcomments setColor:[[self.__c Colors] RGB:(int) (255) :(int) (235) :(int) (128)]];
[B4IRDebugUtils shared].currentLine=458759;
 //BA.debugLineNum = 458759;BA.debugLine="lblResult.Text = \"\"					' Sets lblResult.Text to";
[self._lblresult setText:@""];
[B4IRDebugUtils shared].currentLine=458760;
 //BA.debugLineNum = 458760;BA.debugLine="btn0.Visible = False";
[self._btn0 setVisible:[self.__c False]];
[B4IRDebugUtils shared].currentLine=458761;
 //BA.debugLineNum = 458761;BA.debugLine="End Sub";
return @"";
}
- (NSString*)  _btnaction_click{
[B4IRDebugUtils shared].currentModule=@"main";
if ([B4IDebug shouldDelegate: @"btnaction_click"])
	return ((NSString*) [B4IDebug delegate:self.bi :@"btnaction_click" :nil]);
[B4IRDebugUtils shared].currentLine=393216;
 //BA.debugLineNum = 393216;BA.debugLine="Private Sub btnAction_Click";
[B4IRDebugUtils shared].currentLine=393217;
 //BA.debugLineNum = 393217;BA.debugLine="If btnAction.Text = \"O K\" Then";
if ([[self._btnaction Text] isEqual:@"O K"]) { 
[B4IRDebugUtils shared].currentLine=393218;
 //BA.debugLineNum = 393218;BA.debugLine="If lblResult.Text=\"\" Then";
if ([[self._lblresult Text] isEqual:@""]) { 
[B4IRDebugUtils shared].currentLine=393219;
 //BA.debugLineNum = 393219;BA.debugLine="Msgbox(\"No result entered\",\"E R R O R\")";
[self.__c Msgbox:@"No result entered" :@"E R R O R"];
 }else {
[B4IRDebugUtils shared].currentLine=393221;
 //BA.debugLineNum = 393221;BA.debugLine="CheckResult";
[self _checkresult];
 };
 }else {
[B4IRDebugUtils shared].currentLine=393224;
 //BA.debugLineNum = 393224;BA.debugLine="New";
[self _new];
[B4IRDebugUtils shared].currentLine=393225;
 //BA.debugLineNum = 393225;BA.debugLine="btnAction.Text = \"O K\"";
[self._btnaction setText:@"O K"];
[B4IRDebugUtils shared].currentLine=393226;
 //BA.debugLineNum = 393226;BA.debugLine="lblResult.Text = \"\"";
[self._lblresult setText:@""];
 };
[B4IRDebugUtils shared].currentLine=393228;
 //BA.debugLineNum = 393228;BA.debugLine="End Sub";
return @"";
}
- (NSString*)  _checkresult{
[B4IRDebugUtils shared].currentModule=@"main";
if ([B4IDebug shouldDelegate: @"checkresult"])
	return ((NSString*) [B4IDebug delegate:self.bi :@"checkresult" :nil]);
[B4IRDebugUtils shared].currentLine=524288;
 //BA.debugLineNum = 524288;BA.debugLine="Private Sub CheckResult";
[B4IRDebugUtils shared].currentLine=524289;
 //BA.debugLineNum = 524289;BA.debugLine="If lblResult.Text = Number1 + Number2 Then";
if ([[self._lblresult Text] isEqual:[self.bi NumberToString:@(self._number1+self._number2)]]) { 
[B4IRDebugUtils shared].currentLine=524290;
 //BA.debugLineNum = 524290;BA.debugLine="lblComments.Text = \"G O O D  result\" & CRLF & \"C";
[self._lblcomments setText:[@[@"G O O D  result",[self.__c CRLF],@"Click on NEW"] componentsJoinedByString:@""]];
[B4IRDebugUtils shared].currentLine=524291;
 //BA.debugLineNum = 524291;BA.debugLine="lblComments.Color = Colors.RGB(128,255,128)	' li";
[self._lblcomments setColor:[[self.__c Colors] RGB:(int) (128) :(int) (255) :(int) (128)]];
[B4IRDebugUtils shared].currentLine=524292;
 //BA.debugLineNum = 524292;BA.debugLine="btnAction.Text = \"N E W\"";
[self._btnaction setText:@"N E W"];
 }else {
[B4IRDebugUtils shared].currentLine=524294;
 //BA.debugLineNum = 524294;BA.debugLine="lblComments.Color = Colors.RGB(255,128,128)	' li";
[self._lblcomments setColor:[[self.__c Colors] RGB:(int) (255) :(int) (128) :(int) (128)]];
[B4IRDebugUtils shared].currentLine=524295;
 //BA.debugLineNum = 524295;BA.debugLine="lblComments.Text = \"W R O N G  result\" & CRLF &";
[self._lblcomments setText:[@[@"W R O N G  result",[self.__c CRLF],@"Enter a new result",[self.__c CRLF],@"and click OK"] componentsJoinedByString:@""]];
 };
[B4IRDebugUtils shared].currentLine=524297;
 //BA.debugLineNum = 524297;BA.debugLine="End Sub";
return @"";
}
- (NSString*)  _btnevent_click{
[B4IRDebugUtils shared].currentModule=@"main";
if ([B4IDebug shouldDelegate: @"btnevent_click"])
	return ((NSString*) [B4IDebug delegate:self.bi :@"btnevent_click" :nil]);
B4IButtonWrapper* _btnsender = nil;
[B4IRDebugUtils shared].currentLine=589824;
 //BA.debugLineNum = 589824;BA.debugLine="Private Sub btnEvent_Click";
[B4IRDebugUtils shared].currentLine=589825;
 //BA.debugLineNum = 589825;BA.debugLine="Private btnSender As Button";
_btnsender = [B4IButtonWrapper new];
[B4IRDebugUtils shared].currentLine=589827;
 //BA.debugLineNum = 589827;BA.debugLine="btnSender = Sender";
_btnsender.object = (UIButton*)([self.__c Sender:self.bi]);
[B4IRDebugUtils shared].currentLine=589829;
 //BA.debugLineNum = 589829;BA.debugLine="Select btnSender.Tag";
switch ([self.bi switchObjectToInt:[_btnsender Tag] :@[(NSObject*)(@"BS")]]) {
case 0: {
[B4IRDebugUtils shared].currentLine=589831;
 //BA.debugLineNum = 589831;BA.debugLine="If lblResult.Text.Length > 0 Then";
if ([[self._lblresult Text] Length]>0) { 
[B4IRDebugUtils shared].currentLine=589832;
 //BA.debugLineNum = 589832;BA.debugLine="lblResult.Text = lblResult.Text.SubString2(0, l";
[self._lblresult setText:[[self._lblresult Text] SubString2:(int) (0) :(int) ([[self._lblresult Text] Length]-1)]];
 };
 break; }
default: {
[B4IRDebugUtils shared].currentLine=589835;
 //BA.debugLineNum = 589835;BA.debugLine="lblResult.Text = lblResult.Text & btnSender.Text";
[self._lblresult setText:[@[[self._lblresult Text],[_btnsender Text]] componentsJoinedByString:@""]];
 break; }
}
;
[B4IRDebugUtils shared].currentLine=589838;
 //BA.debugLineNum = 589838;BA.debugLine="If lblResult.Text.Length = 0 Then";
if ([[self._lblresult Text] Length]==0) { 
[B4IRDebugUtils shared].currentLine=589839;
 //BA.debugLineNum = 589839;BA.debugLine="btn0.Visible = False";
[self._btn0 setVisible:[self.__c False]];
 }else {
[B4IRDebugUtils shared].currentLine=589841;
 //BA.debugLineNum = 589841;BA.debugLine="btn0.Visible = True";
[self._btn0 setVisible:[self.__c True]];
 };
[B4IRDebugUtils shared].currentLine=589843;
 //BA.debugLineNum = 589843;BA.debugLine="End Sub";
return @"";
}
- (NSString*)  _page1_resize:(int) _width :(int) _height{
[B4IRDebugUtils shared].currentModule=@"main";
if ([B4IDebug shouldDelegate: @"page1_resize"])
	return ((NSString*) [B4IDebug delegate:self.bi :@"page1_resize::" :@[@(_width),@(_height)]]);
[B4IRDebugUtils shared].currentLine=131072;
 //BA.debugLineNum = 131072;BA.debugLine="Private Sub Page1_Resize(Width As Int, Height As I";
[B4IRDebugUtils shared].currentLine=131074;
 //BA.debugLineNum = 131074;BA.debugLine="End Sub";
return @"";
}

- (void)initializeStaticModules {
    [[b4i_main new]initializeModule];

}
- (NSString*)  _process_globals{
[B4IRDebugUtils shared].currentModule=@"main";
if ([B4IDebug shouldDelegate: @"process_globals"])
	return ((NSString*) [B4IDebug delegate:self.bi :@"process_globals" :nil]);
[B4IRDebugUtils shared].currentLine=0;
 //BA.debugLineNum = 0;BA.debugLine="Sub Process_Globals";
[B4IRDebugUtils shared].currentLine=3;
 //BA.debugLineNum = 3;BA.debugLine="Public App As Application";
self._app = [B4IApplicationWrapper new];
[B4IRDebugUtils shared].currentLine=4;
 //BA.debugLineNum = 4;BA.debugLine="Public NavControl As NavigationController";
self._navcontrol = [B4INavigationControllerWrapper new];
[B4IRDebugUtils shared].currentLine=5;
 //BA.debugLineNum = 5;BA.debugLine="Private Page1 As Page";
self._page1 = [B4IPage new];
[B4IRDebugUtils shared].currentLine=7;
 //BA.debugLineNum = 7;BA.debugLine="Private btnAction, btn0 As Button";
self._btnaction = [B4IButtonWrapper new];
self._btn0 = [B4IButtonWrapper new];
[B4IRDebugUtils shared].currentLine=8;
 //BA.debugLineNum = 8;BA.debugLine="Private lblMathSign As Label";
self._lblmathsign = [B4ILabelWrapper new];
[B4IRDebugUtils shared].currentLine=9;
 //BA.debugLineNum = 9;BA.debugLine="Private lblComments As Label";
self._lblcomments = [B4ILabelWrapper new];
[B4IRDebugUtils shared].currentLine=10;
 //BA.debugLineNum = 10;BA.debugLine="Private lblNumber1 As Label";
self._lblnumber1 = [B4ILabelWrapper new];
[B4IRDebugUtils shared].currentLine=11;
 //BA.debugLineNum = 11;BA.debugLine="Private lblNumber2 As Label";
self._lblnumber2 = [B4ILabelWrapper new];
[B4IRDebugUtils shared].currentLine=12;
 //BA.debugLineNum = 12;BA.debugLine="Private lblResult As Label";
self._lblresult = [B4ILabelWrapper new];
[B4IRDebugUtils shared].currentLine=14;
 //BA.debugLineNum = 14;BA.debugLine="Private Number1, Number2 As Int";
self._number1 = 0;
self._number2 = 0;
[B4IRDebugUtils shared].currentLine=15;
 //BA.debugLineNum = 15;BA.debugLine="End Sub";
return @"";
}
@end