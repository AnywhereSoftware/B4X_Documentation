
#import "iCore.h"
@interface LS_main:NSObject
@end

@implementation LS_main

- (void)LS_general:(B4ILayoutData*)views :(int)width :(int)height{
[B4ILayoutBuilder setScaleRate:0.3];
//BA.debugLineNum = 2;BA.debugLine="AutoScaleAll"[main/General script]
[B4ILayoutBuilder scaleAll:views :width :height];
//BA.debugLineNum = 4;BA.debugLine="lblMathSign.HorizontalCenter = 50%x	' centers the view on the middle of the screen"[main/General script]
[views get:@"lblmathsign"].Left = (int)((50 / 100.0 * width) - ([views get:@"lblmathsign"].Width / 2));
//BA.debugLineNum = 5;BA.debugLine="lblNumber1.Right = lblMathSign.Left	' aligns the right edge ont the left edge"[main/General script]
[views get:@"lblnumber1"].Left = (int)(([views get:@"lblmathsign"].Left) - ([views get:@"lblnumber1"].Width));
//BA.debugLineNum = 6;BA.debugLine="lblNumber2.Left = lblMathSign.Right	' aligns the left edge ont the right edge"[main/General script]
[views get:@"lblnumber2"].Left = (int)(([views get:@"lblmathsign"].Left + [views get:@"lblmathsign"].Width));
//BA.debugLineNum = 7;BA.debugLine="lblResult.HorizontalCenter = 50%x	' centers the view on the middle of the screen"[main/General script]
[views get:@"lblresult"].Left = (int)((50 / 100.0 * width) - ([views get:@"lblresult"].Width / 2));
//BA.debugLineNum = 8;BA.debugLine="lblComments.HorizontalCenter = 50%x	' centers the view on the middle of the screen"[main/General script]
[views get:@"lblcomments"].Left = (int)((50 / 100.0 * width) - ([views get:@"lblcomments"].Width / 2));
//BA.debugLineNum = 9;BA.debugLine="pnlKeyboard.HorizontalCenter = 50%x	' centers the view on the middle of the screen"[main/General script]
[views get:@"pnlkeyboard"].Left = (int)((50 / 100.0 * width) - ([views get:@"pnlkeyboard"].Width / 2));

}
@end