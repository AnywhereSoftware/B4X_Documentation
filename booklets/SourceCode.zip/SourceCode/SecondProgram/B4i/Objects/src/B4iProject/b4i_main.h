#import "iCore.h"
#import "iDebug2.h"
@interface b4i_main : B4IStaticModule
- (NSString*)  _application_active;
- (NSString*)  _application_background;
- (NSString*)  _application_inactive;
- (NSString*)  _application_start:(B4INavigationControllerWrapper*) _nav;
- (NSString*)  _btnaction_click;
- (NSString*)  _btnevent_click;
- (NSString*)  _checkresult;
- (NSString*)  _new;
- (NSString*)  _page1_resize:(int) _width :(int) _height;
- (NSString*)  _process_globals;
@property (nonatomic)B4IApplicationWrapper* _app;
@property (nonatomic)B4INavigationControllerWrapper* _navcontrol;
@property (nonatomic)B4IPage* _page1;
@property (nonatomic)B4IButtonWrapper* _btnaction;
@property (nonatomic)B4IButtonWrapper* _btn0;
@property (nonatomic)B4ILabelWrapper* _lblmathsign;
@property (nonatomic)B4ILabelWrapper* _lblcomments;
@property (nonatomic)B4ILabelWrapper* _lblnumber1;
@property (nonatomic)B4ILabelWrapper* _lblnumber2;
@property (nonatomic)B4ILabelWrapper* _lblresult;
@property (nonatomic)int _number1;
@property (nonatomic)int _number2;
@end
