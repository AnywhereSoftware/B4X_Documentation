package anywheresoftware.b4i.example;

import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.pc.*;

public class b4i_main_subs_0 {


public static RemoteObject  _application_active() throws Exception{
try {
		Debug.PushSubsStack("Application_Active (main) ","main",0,b4i_main.ba,b4i_main.mostCurrent,42);
if (RapidSub.canDelegate("application_active")) return b4i_main.remoteMe.runUserSub(false, "main","application_active");
 BA.debugLineNum = 42;BA.debugLine="Private Sub Application_Active";
Debug.ShouldStop(512);
 BA.debugLineNum = 44;BA.debugLine="End Sub";
Debug.ShouldStop(2048);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _application_background() throws Exception{
try {
		Debug.PushSubsStack("Application_Background (main) ","main",0,b4i_main.ba,b4i_main.mostCurrent,50);
if (RapidSub.canDelegate("application_background")) return b4i_main.remoteMe.runUserSub(false, "main","application_background");
 BA.debugLineNum = 50;BA.debugLine="Private Sub Application_Background";
Debug.ShouldStop(131072);
 BA.debugLineNum = 52;BA.debugLine="End Sub";
Debug.ShouldStop(524288);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _application_inactive() throws Exception{
try {
		Debug.PushSubsStack("Application_Inactive (main) ","main",0,b4i_main.ba,b4i_main.mostCurrent,46);
if (RapidSub.canDelegate("application_inactive")) return b4i_main.remoteMe.runUserSub(false, "main","application_inactive");
 BA.debugLineNum = 46;BA.debugLine="Private Sub Application_Inactive";
Debug.ShouldStop(8192);
 BA.debugLineNum = 48;BA.debugLine="End Sub";
Debug.ShouldStop(32768);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _application_start(RemoteObject _nav) throws Exception{
try {
		Debug.PushSubsStack("Application_Start (main) ","main",0,b4i_main.ba,b4i_main.mostCurrent,27);
if (RapidSub.canDelegate("application_start")) return b4i_main.remoteMe.runUserSub(false, "main","application_start", _nav);
Debug.locals.put("Nav", _nav);
 BA.debugLineNum = 27;BA.debugLine="Private Sub Application_Start (Nav As NavigationCo";
Debug.ShouldStop(67108864);
 BA.debugLineNum = 28;BA.debugLine="NavControl = Nav";
Debug.ShouldStop(134217728);
b4i_main._navcontrol = _nav;
 BA.debugLineNum = 29;BA.debugLine="Page1.Initialize(\"Page1\")";
Debug.ShouldStop(268435456);
b4i_main._page1.runVoidMethod ("Initialize::",b4i_main.ba,(Object)(RemoteObject.createImmutable("Page1")));
 BA.debugLineNum = 30;BA.debugLine="Page1.RootPanel.Color = Colors.White";
Debug.ShouldStop(536870912);
b4i_main._page1.runMethod(false,"RootPanel").runMethod(true,"setColor:",b4i_main.__c.runMethod(false,"Colors").runMethod(true,"White"));
 BA.debugLineNum = 31;BA.debugLine="Page1.RootPanel.LoadLayout(\"Main\")";
Debug.ShouldStop(1073741824);
b4i_main._page1.runMethod(false,"RootPanel").runMethodAndSync(false,"LoadLayout::",(Object)(RemoteObject.createImmutable("Main")),b4i_main.ba);
 BA.debugLineNum = 32;BA.debugLine="Page1.Title = \"Calc Trainer\"";
Debug.ShouldStop(-2147483648);
b4i_main._page1.runMethod(true,"setTitle:",BA.ObjectToString("Calc Trainer"));
 BA.debugLineNum = 33;BA.debugLine="NavControl.ShowPage(Page1)";
Debug.ShouldStop(1);
b4i_main._navcontrol.runVoidMethod ("ShowPage:",(Object)(((b4i_main._page1).getObject())));
 BA.debugLineNum = 35;BA.debugLine="New";
Debug.ShouldStop(4);
_new();
 BA.debugLineNum = 36;BA.debugLine="End Sub";
Debug.ShouldStop(8);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _btnaction_click() throws Exception{
try {
		Debug.PushSubsStack("btnAction_Click (main) ","main",0,b4i_main.ba,b4i_main.mostCurrent,54);
if (RapidSub.canDelegate("btnaction_click")) return b4i_main.remoteMe.runUserSub(false, "main","btnaction_click");
 BA.debugLineNum = 54;BA.debugLine="Private Sub btnAction_Click";
Debug.ShouldStop(2097152);
 BA.debugLineNum = 55;BA.debugLine="If btnAction.Text = \"O K\" Then";
Debug.ShouldStop(4194304);
if (RemoteObject.solveBoolean("=",b4i_main._btnaction.runMethod(true,"Text"),BA.ObjectToString("O K"))) { 
 BA.debugLineNum = 56;BA.debugLine="If lblResult.Text=\"\" Then";
Debug.ShouldStop(8388608);
if (RemoteObject.solveBoolean("=",b4i_main._lblresult.runMethod(true,"Text"),BA.ObjectToString(""))) { 
 BA.debugLineNum = 57;BA.debugLine="Msgbox(\"No result entered\",\"E R R O R\")";
Debug.ShouldStop(16777216);
b4i_main.__c.runVoidMethodAndSync ("Msgbox::",(Object)(BA.ObjectToString("No result entered")),(Object)(RemoteObject.createImmutable("E R R O R")));
 }else {
 BA.debugLineNum = 59;BA.debugLine="CheckResult";
Debug.ShouldStop(67108864);
_checkresult();
 };
 }else {
 BA.debugLineNum = 62;BA.debugLine="New";
Debug.ShouldStop(536870912);
_new();
 BA.debugLineNum = 63;BA.debugLine="btnAction.Text = \"O K\"";
Debug.ShouldStop(1073741824);
b4i_main._btnaction.runMethod(true,"setText:",BA.ObjectToString("O K"));
 BA.debugLineNum = 64;BA.debugLine="lblResult.Text = \"\"";
Debug.ShouldStop(-2147483648);
b4i_main._lblresult.runMethod(true,"setText:",BA.ObjectToString(""));
 };
 BA.debugLineNum = 66;BA.debugLine="End Sub";
Debug.ShouldStop(2);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _btnevent_click() throws Exception{
try {
		Debug.PushSubsStack("btnEvent_Click (main) ","main",0,b4i_main.ba,b4i_main.mostCurrent,90);
if (RapidSub.canDelegate("btnevent_click")) return b4i_main.remoteMe.runUserSub(false, "main","btnevent_click");
RemoteObject _btnsender = RemoteObject.declareNull("B4IButtonWrapper");
 BA.debugLineNum = 90;BA.debugLine="Private Sub btnEvent_Click";
Debug.ShouldStop(33554432);
 BA.debugLineNum = 91;BA.debugLine="Private btnSender As Button";
Debug.ShouldStop(67108864);
_btnsender = RemoteObject.createNew ("B4IButtonWrapper");Debug.locals.put("btnSender", _btnsender);
 BA.debugLineNum = 93;BA.debugLine="btnSender = Sender";
Debug.ShouldStop(268435456);
_btnsender.setObject(b4i_main.__c.runMethod(false,"Sender:",b4i_main.ba));
 BA.debugLineNum = 95;BA.debugLine="Select btnSender.Tag";
Debug.ShouldStop(1073741824);
switch (BA.switchObjectToInt(_btnsender.runMethod(false,"Tag"),RemoteObject.createImmutable(("BS")))) {
case 0: {
 BA.debugLineNum = 97;BA.debugLine="If lblResult.Text.Length > 0 Then";
Debug.ShouldStop(1);
if (RemoteObject.solveBoolean(">",b4i_main._lblresult.runMethod(true,"Text").runMethod(true,"Length"),BA.numberCast(double.class, 0))) { 
 BA.debugLineNum = 98;BA.debugLine="lblResult.Text = lblResult.Text.SubString2(0, l";
Debug.ShouldStop(2);
b4i_main._lblresult.runMethod(true,"setText:",b4i_main._lblresult.runMethod(true,"Text").runMethod(true,"SubString2::",(Object)(BA.numberCast(int.class, 0)),(Object)(RemoteObject.solve(new RemoteObject[] {b4i_main._lblresult.runMethod(true,"Text").runMethod(true,"Length"),RemoteObject.createImmutable(1)}, "-",1, 1))));
 };
 break; }
default: {
 BA.debugLineNum = 101;BA.debugLine="lblResult.Text = lblResult.Text & btnSender.Text";
Debug.ShouldStop(16);
b4i_main._lblresult.runMethod(true,"setText:",RemoteObject.concat(b4i_main._lblresult.runMethod(true,"Text"),_btnsender.runMethod(true,"Text")));
 break; }
}
;
 BA.debugLineNum = 104;BA.debugLine="If lblResult.Text.Length = 0 Then";
Debug.ShouldStop(128);
if (RemoteObject.solveBoolean("=",b4i_main._lblresult.runMethod(true,"Text").runMethod(true,"Length"),BA.numberCast(double.class, 0))) { 
 BA.debugLineNum = 105;BA.debugLine="btn0.Visible = False";
Debug.ShouldStop(256);
b4i_main._btn0.runMethod(true,"setVisible:",b4i_main.__c.runMethod(true,"False"));
 }else {
 BA.debugLineNum = 107;BA.debugLine="btn0.Visible = True";
Debug.ShouldStop(1024);
b4i_main._btn0.runMethod(true,"setVisible:",b4i_main.__c.runMethod(true,"True"));
 };
 BA.debugLineNum = 109;BA.debugLine="End Sub";
Debug.ShouldStop(4096);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _checkresult() throws Exception{
try {
		Debug.PushSubsStack("CheckResult (main) ","main",0,b4i_main.ba,b4i_main.mostCurrent,79);
if (RapidSub.canDelegate("checkresult")) return b4i_main.remoteMe.runUserSub(false, "main","checkresult");
 BA.debugLineNum = 79;BA.debugLine="Private Sub CheckResult";
Debug.ShouldStop(16384);
 BA.debugLineNum = 80;BA.debugLine="If lblResult.Text = Number1 + Number2 Then";
Debug.ShouldStop(32768);
if (RemoteObject.solveBoolean("=",b4i_main._lblresult.runMethod(true,"Text"),BA.NumberToString(RemoteObject.solve(new RemoteObject[] {b4i_main._number1,b4i_main._number2}, "+",1, 1)))) { 
 BA.debugLineNum = 81;BA.debugLine="lblComments.Text = \"G O O D  result\" & CRLF & \"C";
Debug.ShouldStop(65536);
b4i_main._lblcomments.runMethod(true,"setText:",RemoteObject.concat(RemoteObject.createImmutable("G O O D  result"),b4i_main.__c.runMethod(true,"CRLF"),RemoteObject.createImmutable("Click on NEW")));
 BA.debugLineNum = 82;BA.debugLine="lblComments.Color = Colors.RGB(128,255,128)	' li";
Debug.ShouldStop(131072);
b4i_main._lblcomments.runMethod(true,"setColor:",b4i_main.__c.runMethod(false,"Colors").runMethod(true,"RGB:::",(Object)(BA.numberCast(int.class, 128)),(Object)(BA.numberCast(int.class, 255)),(Object)(BA.numberCast(int.class, 128))));
 BA.debugLineNum = 83;BA.debugLine="btnAction.Text = \"N E W\"";
Debug.ShouldStop(262144);
b4i_main._btnaction.runMethod(true,"setText:",BA.ObjectToString("N E W"));
 }else {
 BA.debugLineNum = 85;BA.debugLine="lblComments.Color = Colors.RGB(255,128,128)	' li";
Debug.ShouldStop(1048576);
b4i_main._lblcomments.runMethod(true,"setColor:",b4i_main.__c.runMethod(false,"Colors").runMethod(true,"RGB:::",(Object)(BA.numberCast(int.class, 255)),(Object)(BA.numberCast(int.class, 128)),(Object)(BA.numberCast(int.class, 128))));
 BA.debugLineNum = 86;BA.debugLine="lblComments.Text = \"W R O N G  result\" & CRLF &";
Debug.ShouldStop(2097152);
b4i_main._lblcomments.runMethod(true,"setText:",RemoteObject.concat(RemoteObject.createImmutable("W R O N G  result"),b4i_main.__c.runMethod(true,"CRLF"),RemoteObject.createImmutable("Enter a new result"),b4i_main.__c.runMethod(true,"CRLF"),RemoteObject.createImmutable("and click OK")));
 };
 BA.debugLineNum = 88;BA.debugLine="End Sub";
Debug.ShouldStop(8388608);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _new() throws Exception{
try {
		Debug.PushSubsStack("New (main) ","main",0,b4i_main.ba,b4i_main.mostCurrent,68);
if (RapidSub.canDelegate("new")) return b4i_main.remoteMe.runUserSub(false, "main","new");
 BA.debugLineNum = 68;BA.debugLine="Private Sub New";
Debug.ShouldStop(8);
 BA.debugLineNum = 69;BA.debugLine="Number1 = Rnd(1, 10)				' Generates a random numb";
Debug.ShouldStop(16);
b4i_main._number1 = b4i_main.__c.runMethod(true,"Rnd::",(Object)(BA.numberCast(int.class, 1)),(Object)(BA.numberCast(int.class, 10)));
 BA.debugLineNum = 70;BA.debugLine="Number2 = Rnd(1, 10)				' Generates a random numb";
Debug.ShouldStop(32);
b4i_main._number2 = b4i_main.__c.runMethod(true,"Rnd::",(Object)(BA.numberCast(int.class, 1)),(Object)(BA.numberCast(int.class, 10)));
 BA.debugLineNum = 71;BA.debugLine="lblNumber1.Text = Number1		' Displays Number1 in";
Debug.ShouldStop(64);
b4i_main._lblnumber1.runMethod(true,"setText:",BA.NumberToString(b4i_main._number1));
 BA.debugLineNum = 72;BA.debugLine="lblNumber2.Text = Number2		' Displays Number2 in";
Debug.ShouldStop(128);
b4i_main._lblnumber2.runMethod(true,"setText:",BA.NumberToString(b4i_main._number2));
 BA.debugLineNum = 73;BA.debugLine="lblComments.Text = \"Enter the result\" & CRLF & \"a";
Debug.ShouldStop(256);
b4i_main._lblcomments.runMethod(true,"setText:",RemoteObject.concat(RemoteObject.createImmutable("Enter the result"),b4i_main.__c.runMethod(true,"CRLF"),RemoteObject.createImmutable("and click on OK")));
 BA.debugLineNum = 74;BA.debugLine="lblComments.Color = Colors.RGB(255,235,128)	' yel";
Debug.ShouldStop(512);
b4i_main._lblcomments.runMethod(true,"setColor:",b4i_main.__c.runMethod(false,"Colors").runMethod(true,"RGB:::",(Object)(BA.numberCast(int.class, 255)),(Object)(BA.numberCast(int.class, 235)),(Object)(BA.numberCast(int.class, 128))));
 BA.debugLineNum = 75;BA.debugLine="lblResult.Text = \"\"					' Sets lblResult.Text to";
Debug.ShouldStop(1024);
b4i_main._lblresult.runMethod(true,"setText:",BA.ObjectToString(""));
 BA.debugLineNum = 76;BA.debugLine="btn0.Visible = False";
Debug.ShouldStop(2048);
b4i_main._btn0.runMethod(true,"setVisible:",b4i_main.__c.runMethod(true,"False"));
 BA.debugLineNum = 77;BA.debugLine="End Sub";
Debug.ShouldStop(4096);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _page1_resize(RemoteObject _width,RemoteObject _height) throws Exception{
try {
		Debug.PushSubsStack("Page1_Resize (main) ","main",0,b4i_main.ba,b4i_main.mostCurrent,38);
if (RapidSub.canDelegate("page1_resize")) return b4i_main.remoteMe.runUserSub(false, "main","page1_resize", _width, _height);
Debug.locals.put("Width", _width);
Debug.locals.put("Height", _height);
 BA.debugLineNum = 38;BA.debugLine="Private Sub Page1_Resize(Width As Int, Height As I";
Debug.ShouldStop(32);
 BA.debugLineNum = 40;BA.debugLine="End Sub";
Debug.ShouldStop(128);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _process_globals() throws Exception{
 //BA.debugLineNum = 10;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 13;BA.debugLine="Public App As Application";
b4i_main._app = RemoteObject.createNew ("B4IApplicationWrapper");
 //BA.debugLineNum = 14;BA.debugLine="Public NavControl As NavigationController";
b4i_main._navcontrol = RemoteObject.createNew ("B4INavigationControllerWrapper");
 //BA.debugLineNum = 15;BA.debugLine="Private Page1 As Page";
b4i_main._page1 = RemoteObject.createNew ("B4IPage");
 //BA.debugLineNum = 17;BA.debugLine="Private btnAction, btn0 As Button";
b4i_main._btnaction = RemoteObject.createNew ("B4IButtonWrapper");
b4i_main._btn0 = RemoteObject.createNew ("B4IButtonWrapper");
 //BA.debugLineNum = 18;BA.debugLine="Private lblMathSign As Label";
b4i_main._lblmathsign = RemoteObject.createNew ("B4ILabelWrapper");
 //BA.debugLineNum = 19;BA.debugLine="Private lblComments As Label";
b4i_main._lblcomments = RemoteObject.createNew ("B4ILabelWrapper");
 //BA.debugLineNum = 20;BA.debugLine="Private lblNumber1 As Label";
b4i_main._lblnumber1 = RemoteObject.createNew ("B4ILabelWrapper");
 //BA.debugLineNum = 21;BA.debugLine="Private lblNumber2 As Label";
b4i_main._lblnumber2 = RemoteObject.createNew ("B4ILabelWrapper");
 //BA.debugLineNum = 22;BA.debugLine="Private lblResult As Label";
b4i_main._lblresult = RemoteObject.createNew ("B4ILabelWrapper");
 //BA.debugLineNum = 24;BA.debugLine="Private Number1, Number2 As Int";
b4i_main._number1 = RemoteObject.createImmutable(0);
b4i_main._number2 = RemoteObject.createImmutable(0);
 //BA.debugLineNum = 25;BA.debugLine="End Sub";
return RemoteObject.createImmutable("");
}
}