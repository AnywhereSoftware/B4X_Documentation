package b4a.designeranchor.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_main{

public static void LS_general(java.util.LinkedHashMap<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
//BA.debugLineNum = 3;BA.debugLine="ListView1.Width = 50%x - 20dip"[main/General script]
views.get("listview1").vw.setWidth((int)((50d / 100 * width)-(20d * scale)));
//BA.debugLineNum = 4;BA.debugLine="ScrollView1.SetLeftAndRight(50%x + 10dip, 100%x - 10dip)"[main/General script]
views.get("scrollview1").vw.setLeft((int)((50d / 100 * width)+(10d * scale)));
views.get("scrollview1").vw.setWidth((int)((100d / 100 * width)-(10d * scale) - ((50d / 100 * width)+(10d * scale))));

}
}