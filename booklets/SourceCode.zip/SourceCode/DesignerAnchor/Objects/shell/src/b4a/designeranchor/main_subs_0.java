package b4a.designeranchor;

import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.pc.*;

public class main_subs_0 {


public static RemoteObject  _activity_create(RemoteObject _firsttime) throws Exception{
try {
		Debug.PushSubsStack("Activity_Create (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,24);
if (RapidSub.canDelegate("activity_create")) return main.remoteMe.runUserSub(false, "main","activity_create", _firsttime);
Debug.locals.put("FirstTime", _firsttime);
 BA.debugLineNum = 24;BA.debugLine="Sub Activity_Create(FirstTime As Boolean)";
Debug.ShouldStop(8388608);
 BA.debugLineNum = 25;BA.debugLine="Activity.LoadLayout(\"Main1\")";
Debug.ShouldStop(16777216);
main.mostCurrent._activity.runMethodAndSync(false,"LoadLayout",(Object)(RemoteObject.createImmutable("Main1")),main.mostCurrent.activityBA);
 BA.debugLineNum = 28;BA.debugLine="End Sub";
Debug.ShouldStop(134217728);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _activity_pause(RemoteObject _userclosed) throws Exception{
try {
		Debug.PushSubsStack("Activity_Pause (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,34);
if (RapidSub.canDelegate("activity_pause")) return main.remoteMe.runUserSub(false, "main","activity_pause", _userclosed);
Debug.locals.put("UserClosed", _userclosed);
 BA.debugLineNum = 34;BA.debugLine="Sub Activity_Pause (UserClosed As Boolean)";
Debug.ShouldStop(2);
 BA.debugLineNum = 36;BA.debugLine="End Sub";
Debug.ShouldStop(8);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _activity_resume() throws Exception{
try {
		Debug.PushSubsStack("Activity_Resume (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,30);
if (RapidSub.canDelegate("activity_resume")) return main.remoteMe.runUserSub(false, "main","activity_resume");
 BA.debugLineNum = 30;BA.debugLine="Sub Activity_Resume";
Debug.ShouldStop(536870912);
 BA.debugLineNum = 32;BA.debugLine="End Sub";
Debug.ShouldStop(-2147483648);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _filllistview() throws Exception{
try {
		Debug.PushSubsStack("FillListView (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,38);
if (RapidSub.canDelegate("filllistview")) return main.remoteMe.runUserSub(false, "main","filllistview");
RemoteObject _i = RemoteObject.createImmutable(0);
 BA.debugLineNum = 38;BA.debugLine="Sub FillListView";
Debug.ShouldStop(32);
 BA.debugLineNum = 39;BA.debugLine="Private i As Int";
Debug.ShouldStop(64);
_i = RemoteObject.createImmutable(0);Debug.locals.put("i", _i);
 BA.debugLineNum = 41;BA.debugLine="For i = 0 To 20";
Debug.ShouldStop(256);
{
final int step15 = 1;
final int limit15 = 20;
for (_i = BA.numberCast(int.class, 0); (step15 > 0 && _i.<Integer>get().intValue() <= limit15) || (step15 < 0 && _i.<Integer>get().intValue() >= limit15); _i = RemoteObject.createImmutable((int)(0 + _i.<Integer>get().intValue() + step15))) {
Debug.locals.put("i", _i);
 BA.debugLineNum = 42;BA.debugLine="ListView1.AddSingleLine(\"Test \" & i)";
Debug.ShouldStop(512);
main.mostCurrent._listview1.runVoidMethod ("AddSingleLine",(Object)(RemoteObject.concat(RemoteObject.createImmutable("Test "),_i)));
 }
}Debug.locals.put("i", _i);
;
 BA.debugLineNum = 44;BA.debugLine="End Sub";
Debug.ShouldStop(2048);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _fillscroolview() throws Exception{
try {
		Debug.PushSubsStack("FillScroolView (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,46);
if (RapidSub.canDelegate("fillscroolview")) return main.remoteMe.runUserSub(false, "main","fillscroolview");
RemoteObject _i = RemoteObject.createImmutable(0);
RemoteObject _lblheight = RemoteObject.createImmutable(0);
RemoteObject _lbl = RemoteObject.declareNull("anywheresoftware.b4a.objects.LabelWrapper");
 BA.debugLineNum = 46;BA.debugLine="Sub FillScroolView";
Debug.ShouldStop(8192);
 BA.debugLineNum = 47;BA.debugLine="Private i As Int";
Debug.ShouldStop(16384);
_i = RemoteObject.createImmutable(0);Debug.locals.put("i", _i);
 BA.debugLineNum = 48;BA.debugLine="Private lblHeight = 30dip As Int";
Debug.ShouldStop(32768);
_lblheight = main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 30)));Debug.locals.put("lblHeight", _lblheight);Debug.locals.put("lblHeight", _lblheight);
 BA.debugLineNum = 50;BA.debugLine="For i = 0 To 20";
Debug.ShouldStop(131072);
{
final int step22 = 1;
final int limit22 = 20;
for (_i = BA.numberCast(int.class, 0); (step22 > 0 && _i.<Integer>get().intValue() <= limit22) || (step22 < 0 && _i.<Integer>get().intValue() >= limit22); _i = RemoteObject.createImmutable((int)(0 + _i.<Integer>get().intValue() + step22))) {
Debug.locals.put("i", _i);
 BA.debugLineNum = 51;BA.debugLine="Private lbl As Label";
Debug.ShouldStop(262144);
_lbl = RemoteObject.createNew ("anywheresoftware.b4a.objects.LabelWrapper");Debug.locals.put("lbl", _lbl);
 BA.debugLineNum = 52;BA.debugLine="lbl.Initialize(\"lbl\")";
Debug.ShouldStop(524288);
_lbl.runVoidMethod ("Initialize",main.mostCurrent.activityBA,(Object)(RemoteObject.createImmutable("lbl")));
 BA.debugLineNum = 53;BA.debugLine="ScrollView1.Panel.AddView(lbl, 0, i * lblHeight,";
Debug.ShouldStop(1048576);
main.mostCurrent._scrollview1.runMethod(false,"getPanel").runVoidMethod ("AddView",(Object)((_lbl.getObject())),(Object)(BA.numberCast(int.class, 0)),(Object)(RemoteObject.solve(new RemoteObject[] {_i,_lblheight}, "*",0, 1)),(Object)(RemoteObject.solve(new RemoteObject[] {main.mostCurrent.__c.runMethod(true,"PerXToCurrent",(Object)(BA.numberCast(float.class, 100)),main.mostCurrent.activityBA),main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 20)))}, "-",1, 1)),(Object)(RemoteObject.solve(new RemoteObject[] {_lblheight,main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 1)))}, "-",1, 1)));
 BA.debugLineNum = 54;BA.debugLine="lbl.Color = Colors.Blue";
Debug.ShouldStop(2097152);
_lbl.runVoidMethod ("setColor",main.mostCurrent.__c.getField(false,"Colors").getField(true,"Blue"));
 BA.debugLineNum = 55;BA.debugLine="lbl.TextColor = Colors.White";
Debug.ShouldStop(4194304);
_lbl.runMethod(true,"setTextColor",main.mostCurrent.__c.getField(false,"Colors").getField(true,"White"));
 BA.debugLineNum = 56;BA.debugLine="lbl.Text = \"Test \" & i";
Debug.ShouldStop(8388608);
_lbl.runMethod(true,"setText",(RemoteObject.concat(RemoteObject.createImmutable("Test "),_i)));
 BA.debugLineNum = 57;BA.debugLine="lbl.Tag = i";
Debug.ShouldStop(16777216);
_lbl.runMethod(false,"setTag",(_i));
 }
}Debug.locals.put("i", _i);
;
 BA.debugLineNum = 59;BA.debugLine="ScrollView1.Panel.Height = i * lblHeight";
Debug.ShouldStop(67108864);
main.mostCurrent._scrollview1.runMethod(false,"getPanel").runMethod(true,"setHeight",RemoteObject.solve(new RemoteObject[] {_i,_lblheight}, "*",0, 1));
 BA.debugLineNum = 60;BA.debugLine="End Sub";
Debug.ShouldStop(134217728);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _globals() throws Exception{
 //BA.debugLineNum = 19;BA.debugLine="Sub Globals";
 //BA.debugLineNum = 20;BA.debugLine="Private ListView1 As ListView";
main.mostCurrent._listview1 = RemoteObject.createNew ("anywheresoftware.b4a.objects.ListViewWrapper");
 //BA.debugLineNum = 21;BA.debugLine="Private ScrollView1 As ScrollView";
main.mostCurrent._scrollview1 = RemoteObject.createNew ("anywheresoftware.b4a.objects.ScrollViewWrapper");
 //BA.debugLineNum = 22;BA.debugLine="End Sub";
return RemoteObject.createImmutable("");
}

public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        main_subs_0._process_globals();
main.myClass = BA.getDeviceClass ("b4a.designeranchor.main");
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}public static RemoteObject  _process_globals() throws Exception{
 //BA.debugLineNum = 15;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 17;BA.debugLine="End Sub";
return RemoteObject.createImmutable("");
}
}